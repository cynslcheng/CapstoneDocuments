package prog3060.FinalExam.Bean;

import javax.ejb.Local;
import javax.persistence.EntityManager;

@Local
public interface ConnectionBeanLocal
{

    boolean isEntityManagerFactoryReady();
    EntityManager createEntityManager();

}



