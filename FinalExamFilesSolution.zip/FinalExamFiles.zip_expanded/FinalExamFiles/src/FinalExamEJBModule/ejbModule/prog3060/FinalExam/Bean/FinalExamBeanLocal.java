package prog3060.FinalExam.Bean;

import java.util.List;

import javax.ejb.Local;
import javax.persistence.EntityManager;

import prog3060.FinalExam.CanadaCensusDB.CensusYear;

@Local
public interface FinalExamBeanLocal
{

    CensusYear getCensusYear(EntityManager tempEntityManager, int tempCensusYearID);

	List<Object[]> getHouseholdAndTotalIncome(EntityManager tempEntityManager, CensusYear censusYear);

}



