package prog3060.FinalExam.Bean;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import prog3060.FinalExam.CanadaCensusDB.CensusYear;
import prog3060.FinalExam.CanadaCensusDB.TotalIncome;

/**
 * Session Bean implementation class FinalExamBean
 */
@Stateless
public class FinalExamBean implements FinalExamBeanLocal
{

// Implement a method that when given a CensusYear.censusYearID
// will retrieve the corresponding CensusYear object from CanadaCensusDB
    @Override
    public CensusYear getCensusYear(EntityManager tempEntityManager, int tempCensusYearID)
    {
        String tempSelectJPQLQuery = "SELECT cy FROM CensusYear cy "
        		+ "WHERE cy.censusYearID = :censusYearID ";
        
        Query tempQuery = tempEntityManager.createQuery(tempSelectJPQLQuery);
        tempQuery.setParameter("censusYearID", tempCensusYearID);
        tempQuery.setMaxResults(1);
        CensusYear tempCensusYear = (CensusYear) tempQuery.getSingleResult();
        
        return tempCensusYear;

    }

// Implement a method that will generate and return the required result
// subject to the conditions defined by the exam paper
    @Override
    public List<Object[]> getHouseholdAndTotalIncome(EntityManager tempEntityManager, CensusYear tempCensusYear)
    {   
        String tempSelectJPQLQuery = "SELECT h, ti FROM Household h "
        		+ "JOIN h.totalIncome ti "
        		+ "JOIN h.householdType ht "
        		+ "JOIN h.householdSize hs "
        		+ "JOIN h.householdsByAgeRange hbar "
        		+ "JOIN h.householdEarners he "
        		+ "JOIN h.geographicArea ga "
        		+ "JOIN h.censusYear cy "
        		+ "WHERE ht.description LIKE :htDescription AND "
        		+ "hs.description LIKE :hsDescription AND "
        		+ "hbar.description LIKE :hbarDescription AND "
        		+ "he.description LIKE :heDescription AND "
        		+ "ti.description NOT LIKE :tiDescription AND "
        		+ "ga.name LIKE :gaDescription AND "
        		+ "cy = :censusYear "
        		+ "ORDER BY ti.id";
        
        Query tempQuery = tempEntityManager.createQuery(tempSelectJPQLQuery);
        tempQuery.setParameter("htDescription", "Other census family households");
        tempQuery.setParameter("hsDescription", "2 or more persons");
        tempQuery.setParameter("hbarDescription", "Total - Households by number of persons aged 0 to 17 years");
        tempQuery.setParameter("heDescription", "1 earner or more");
        tempQuery.setParameter("tiDescription", "Median total income of household ($)");
        tempQuery.setParameter("gaDescription", "Canada");
        tempQuery.setParameter("censusYear", tempCensusYear);
        List<Object[]> tempList = tempQuery.getResultList();
        
        return tempList;

    }

}



