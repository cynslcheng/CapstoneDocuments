package prog3060.FinalExam.Servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import prog3060.FinalExam.Bean.ConnectionBeanLocal;
import prog3060.FinalExam.Bean.FinalExamBeanLocal;
import prog3060.FinalExam.CanadaCensusDB.CensusYear;
import prog3060.FinalExam.CanadaCensusDB.Household;
import prog3060.FinalExam.CanadaCensusDB.TotalIncome;

/**
 * Servlet implementation class AgeGroupsServlet
 */
@WebServlet(name="FinalExamOutputServlet", urlPatterns={"/FinalExamOutput", "/FinalExamOutputServlet"})
public class FinalExamOutputServlet extends HttpServlet
{

    /**
     *  Generated serial version ID
     */
    private static final long serialVersionUID = -5149297429245784091L;

    @EJB
    ConnectionBeanLocal connectionBean;
    @EJB
    FinalExamBeanLocal finalExamBean;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinalExamOutputServlet()
    {

        super();

    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {

        List <String> tempFinalExamOutputList = new ArrayList <String>();
        EntityManager tempEntityManager = null;
        
        try
        {

            tempEntityManager = connectionBean.createEntityManager();

// Start a new transaction
            tempEntityManager.getTransaction().begin();

// Generate and retrieve the output
            CensusYear censusYear = (CensusYear) finalExamBean.getCensusYear(tempEntityManager, 1);
            List<Object[]> tempList = finalExamBean.getHouseholdAndTotalIncome(tempEntityManager, censusYear);
            for (Object[] tempObject : tempList)
            {
            	Household tempHousehold = (Household) tempObject[0];
            	TotalIncome tempTotalIncome = (TotalIncome) tempObject[1];
                tempFinalExamOutputList.add("Year: " + censusYear.getCensusYear() + " Total Income: " + tempTotalIncome.getDescription()
            		+ " Households: " + tempHousehold.getNumberReported());  
            }
            
// Handle the transaction
            
            tempEntityManager.getTransaction().rollback();

        }
        catch (Exception e)
        {

// Handle the exception
            if (tempEntityManager != null)
            {

                tempEntityManager.getTransaction().rollback();

            }
            e.printStackTrace();

            throw new ServletException(e);

        }
        finally
        {

// Free any application managed resources
        	tempEntityManager.close();

        }

// Store the output in the location that finalExamOutput.jsp will look for it

        request.setAttribute("finalExamOutputList", tempFinalExamOutputList);
        request.getRequestDispatcher("/finalExamOutput.jsp").forward(request, response);

    }

}



