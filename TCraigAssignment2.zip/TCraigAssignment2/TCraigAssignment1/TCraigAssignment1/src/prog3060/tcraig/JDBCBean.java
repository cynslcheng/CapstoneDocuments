/*
 * FILE         : JDBCBean.java
 * PROJECT      : PROG3060 - Assignment #2
 * PROGRAMMER   : Thomas Craig, Nick Lee, Cynthia Cheng
 * FIRST VERSION: 25/03/2019
 * DESCRIPTION  : This file holds all of the database logic, connecting to the database 
 * 					and prepared statements for retrieving information
 */
package prog3060.tcraig;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.apache.jasper.tagplugins.jstl.core.If;

import prog3060.models.Age;
import prog3060.models.AgeGroup;
import prog3060.models.CensusYear;
import prog3060.models.GeographicArea;
import prog3060.models.Household;
import prog3060.models.TotalIncome;

public class JDBCBean {

	static final String CONNECTION_STRING = "jdbc:derby://localhost:1527/CanadaCensusDB";

    private static final String PERSISTENCE_UNIT_NAME = "TCraigAssignment1";
    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager entityManager;
	static int geoLevel = 0;
	static int geoCode = 0;
	static int geoAltCode = 0;

	//opens a database connection given a username and password
	public static void OpenConnection(String tempUser, String tempPassword) throws SQLException {
		
 	try { Properties properties = new Properties();
 		properties.setProperty("hibernate.connection.username", tempUser);
 		properties.setProperty("hibernate.connection.password", tempPassword);
 		entityManagerFactory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
 		entityManager = entityManagerFactory.createEntityManager();
 		entityManager.getTransaction().begin();
		
		} catch (Exception e) {
			e.printStackTrace();
			entityManager = null;
		}
	}

	//checks to make sure the connection is open
	public static Boolean testConnection() {
		return entityManager != null;
	}

	//gets the regions on the census and there levels
	public static List<String> GetRegions() {
		String tempSQLSelectQuery = "SELECT ga " 
				+ "FROM GeographicArea ga " + "ORDER BY ga.level";
		
	
		List<String> tempOutputTable = new ArrayList<String>();
		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			List<GeographicArea> geographicAreaList = query.getResultList();
			
			
			for (GeographicArea geographicArea : geographicAreaList)
			{
				String tempName = geographicArea.getName();
				int tempLevel = geographicArea.getLevel();
				int tempCode = geographicArea.getCode();
				int tempAltCode = geographicArea.getAlternativeCode();

				tempOutputTable.add(
						String.format("%5d", tempLevel) + String.format("%10s", ",") + String.format("%100s", tempName)
								+ String.format("%10s", ",") + String.format("%5d", tempCode)
								+ String.format("%10s", ",") + String.format("%5d", tempAltCode));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempOutputTable;
	}

	public static void setGeoLevel(String tempLevel) {
		geoLevel = Integer.parseInt(tempLevel);
	}

	public static void setGeoCode(String tempCode) {
		geoCode = Integer.parseInt(tempCode);
	}
	
	public static void setGeoAltCode(String tempAltCode) {
		geoAltCode = Integer.parseInt(tempAltCode);
	}

	//uses the geolevel and geocode to get the name, code, level, and total population of the region
	public static List<String> GetRegionDetails() {
		
		String tempSQLSelectQuery = "SELECT ga.name, ga.code, ga.alternativeCode, ga.level, a.combined, a.male, a.female, cy.censusYear "
				+ "FROM Age a "
				+ "JOIN a.geographicArea ga "
				+ "JOIN a.censusYear cy "
				+ "WHERE a.ageGroup = 1 AND ga.code = : geoCode AND ga.level = : geoLevel";
		
		String tempSQLSelectHouseholdQuery = "SELECT h.numberReported, h.censusYear "
				+ "FROM Household h "
				+ "JOIN h.geographicArea ga "
				+ "JOIN h.censusYear cy "
				+ "JOIN h.householdType ht "
				+ "JOIN h.householdSize hs "
				+ "JOIN h.householdsByAgeRange hbar "
				+ "JOIN h.householdEarners he "
				+ "JOIN h.totalIncome ti "
				+ "WHERE ga.alternativeCode = : altCode "
				+ "AND cy.censusYear = : censusYear "
				+ "AND ht.description = : type "
				+ "AND hs.description = : size "
				+ "AND he.description = : earners "
				+ "AND ti.description = : income "
				+ "AND hbar.description = : ageRange";

		List<String> tempOutputTable = new ArrayList<String>();
		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
	        query.setParameter("geoCode", geoCode);
	        query.setParameter("geoLevel", geoLevel);
			
			List<Object[]> resultList = query.getResultList();
           	Iterator<Object[]> iterator = resultList.iterator();
			
           	Query householdQuery = entityManager.createQuery(tempSQLSelectHouseholdQuery);
           	householdQuery.setParameter("altCode", geoAltCode);
           	householdQuery.setParameter("censusYear", 2016);
           	householdQuery.setParameter("type", "One couple census family without other persons in the household");
           	householdQuery.setParameter("size", "2 or more persons");
           	householdQuery.setParameter("earners", "1 earner or more");
           	householdQuery.setParameter("income", "$80,000 to $89,999");
           	householdQuery.setParameter("ageRange", "Total - Households by number of persons aged 0 to 17 years");
	        List<Object[]> householdResultList = householdQuery.getResultList();
	        Iterator<Object[]> householdIterator = householdResultList.iterator();
	        Object[] tempHouseholdResultSet = null;
	        if (householdIterator.hasNext()) {
	        	tempHouseholdResultSet = householdIterator.next();
	        }
	        
			while (iterator.hasNext()) {
				Object[] tempResultSet = iterator.next();
				String tempName = tempResultSet[0].toString();
				int tempCode = Integer.parseInt(tempResultSet[1].toString());
				int tempAlternativeCode = Integer.parseInt(tempResultSet[2].toString());
				int tempLevel = Integer.parseInt(tempResultSet[3].toString());
				int tempPop = Integer.parseInt(tempResultSet[4].toString());
				int tempMale = Integer.parseInt(tempResultSet[5].toString());
				int tempFemale = Integer.parseInt(tempResultSet[6].toString());
				int tempYear = Integer.parseInt(tempResultSet[7].toString());

				String tempRow = String.format("%5d", tempLevel)
						+ String.format("%10s", ",")
						+ String.format("%30s", tempName)
						+ String.format("%10s", ",")
						+ String.format("%5d", tempCode)
						+ String.format("%10s", ",")
						+ String.format("%5d", tempAlternativeCode)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempPop)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempMale)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempFemale)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempYear);
				if (tempHouseholdResultSet != null) {
					int tempNumber = Integer.parseInt(tempHouseholdResultSet[0].toString());
					tempRow = tempRow 
							+ String.format("%10s", ",")
							+ String.format("%15d", tempNumber);
				}
				tempOutputTable.add(tempRow);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return tempOutputTable;

	}

	//uses the geolevel and geocode to get all the regions located within the region at the next level down
	public static List<String> GetRegionsBelow() {

		int geoAltCodeHigherLimitation=0;
		int geoAltCodeLowerLimitation=0;
		String tempSQLSelectQuery = "SELECT ga FROM GeographicArea ga "
				                    + "WHERE (0 = : geoLevel AND ga.level = 1) "
				                    + "OR (0 <> : geoLevel AND ga.level = : geoLevelNext "
				                    + "AND ga.alternativeCode BETWEEN : geoLowerLimitation "
				                    + "and  :geoUpperLimitation) "
				                    + "ORDER BY ga.alternativeCode DESC";
		List<String> tempOutputTable = new ArrayList<String>();

		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			query.setParameter("geoLevel", geoLevel);
			query.setParameter("geoLevelNext", geoLevel+1);
			
			if(geoLevel==1)
			{
				geoAltCodeHigherLimitation=999;
				geoAltCodeLowerLimitation=1000;
			
			}
			else if(geoLevel==2)
			{
				geoAltCodeHigherLimitation=99;
				geoAltCodeLowerLimitation=100;
			}
			
			query.setParameter("geoUpperLimitation", geoAltCodeLowerLimitation*geoAltCode+geoAltCodeHigherLimitation);
			query.setParameter("geoLowerLimitation", geoAltCodeLowerLimitation*geoAltCode);
			
			List<GeographicArea> geographicAreaList = query.getResultList();

			for (GeographicArea geographicArea : geographicAreaList)
			{
				String tempName = geographicArea.getName();
				int tempLevel = geographicArea.getLevel();
				int tempAltCode = geographicArea.getAlternativeCode();

				tempOutputTable.add(String.format("%5d", tempLevel) + String.format("%10s", ",") + String.format("%30s", tempName)
				+ String.format("%10s", ",") + String.format("%30s", tempAltCode));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tempOutputTable;
	}

	//gets the male and female population broken down by census year and age group, with age groups being in chunks of 5 years
	public static List<String> GetAgeDetails() {

		String tempSQLSelectQuery = "SELECT ag.description, a.male, a.female, cy.censusYear "
				+ "FROM Age a "
				+ "JOIN a.ageGroup ag "
				+ "JOIN a.censusYear cy "
				+ "JOIN a.geographicArea ga "
				+ "WHERE ga.geographicAreaID = 1 "
				+ "AND a.ageGroup IN (3, 9, 15, 22, 28, 34, 40, 46, 52, 58, 64, 70, 76, 83, 89, 95, 101, 108, 114, 120, 126) "
				+ "ORDER BY a.ageGroup, a.censusYear DESC";
		List<String> tempOutputTable = new ArrayList<String>();

		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			List<Object[]> resultList = query.getResultList();
           	Iterator<Object[]> iterator = resultList.iterator();
           	
			while (iterator.hasNext()) {
				Object[] tempResultSet = iterator.next();
				String tempName = tempResultSet[0].toString();
				String tempYear = tempResultSet[3].toString();
				int tempMale = Integer.parseInt(tempResultSet[1].toString());
				int tempFemale = Integer.parseInt(tempResultSet[2].toString());

				tempOutputTable.add(String.format("%30s", tempName) + String.format("%10s", ",")
						+ String.format("%10s", tempYear) + String.format("%10s", ",") + String.format("%15d", tempMale)
						+ String.format("%10s", ",") + String.format("%15d", tempFemale));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempOutputTable;
	}

	public static List<String> GetHouseholdIncomeDetails() {
		String tempSQLSelectHouseholdQuery = "FROM Household h "
				+ "JOIN h.geographicArea ga "
				+ "JOIN h.censusYear cy "
				+ "JOIN h.householdType ht "
				+ "JOIN h.householdSize hs "
				+ "JOIN h.householdsByAgeRange hbar "
				+ "JOIN h.householdEarners he "
				+ "JOIN h.totalIncome ti "
				+ "WHERE ga.level = : level "
				+ "AND cy.censusYear = : censusYear "
				+ "AND ht.description = : type "
				+ "AND hs.description = : size "
				+ "AND he.description = : earners "
				+ "AND hbar.description = : ageRange "
				+ "ORDER BY h.totalIncome";
		
		String tempSQLSelectHouseholdInfo = "FROM Household h "
				+ "JOIN h.geographicArea ga "
				+ "JOIN h.totalIncome ti "
				+ "WHERE ga.alternativeCode = : altCode "
				+ "AND ti.ID = : incomeID";
		
		List<String> tempOutputTable = new ArrayList<String>();

		try {
			Query householdQuery = entityManager.createQuery(tempSQLSelectHouseholdQuery);
           	householdQuery.setParameter("level", 1);
           	householdQuery.setParameter("censusYear", 2016);
           	householdQuery.setParameter("type", "One couple census family without other persons in the household");
           	householdQuery.setParameter("size", "2 or more persons");
           	householdQuery.setParameter("earners", "1 earner or more");
           	householdQuery.setParameter("ageRange", "Total - Households by number of persons aged 0 to 17 years");
	        List<Object[]> householdResultList = householdQuery.getResultList();
	        Iterator<Object[]> householdIterator = householdResultList.iterator();
	        String[] totalIncomeList = new String[70];

			while (householdIterator.hasNext()) {
				Object[] tempResultSet = householdIterator.next();
				int tempArea = ((GeographicArea) tempResultSet[1]).getAlternativeCode();
				int tempTotalID = ((TotalIncome) tempResultSet[7]).getID();
				int tempReported = ((Household) tempResultSet[0]).getNumberReported();

				if (totalIncomeList[tempArea] != null) {
					totalIncomeList[tempArea] += new String(new char[tempReported]).replace("\0",(tempTotalID+", "));
				}
				else {
					totalIncomeList[tempArea] = new String(new char[tempReported]).replace("\0",(tempTotalID+", "));
				}
						
			}

			Map<Integer, Integer> tempMedianValues = new HashMap<Integer, Integer>();
			for (int i = 0; i < totalIncomeList.length; i++) {
				int median = 0;
				if (totalIncomeList[i] != null) {
					String[] tempString = totalIncomeList[i].split(",");
					double[] tempValues = new double[tempString.length];
					for (int j = 0; j < tempString.length - 1; j++) {
						tempValues[j] = Double.parseDouble(tempString[j]);
					}
					Arrays.sort(tempValues);
				    int totalElements = tempValues.length;
				    if (totalElements % 2 == 0) {
				       double sumOfMiddleElements = tempValues[totalElements / 2] + tempValues[totalElements / 2 - 1];
				       median = (int) (sumOfMiddleElements) / 2;
				    } 
				    else {
				       median = (int) tempValues[totalElements / 2];
				    }
				}
				tempMedianValues.put(i, median);
			}
			Stream<Map.Entry<Integer,Integer>> sortedMedianValues =
					tempMedianValues.entrySet().stream()
				       .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()));
			sortedMedianValues.forEach(region -> {
					if (!region.getValue().equals(0)) {
					    Query householdInfoQuery = entityManager.createQuery(tempSQLSelectHouseholdInfo);
					    householdInfoQuery.setParameter("altCode", region.getKey());
					    householdInfoQuery.setParameter("incomeID", region.getValue());
					    List<Object[]> householdInfoResultList = householdInfoQuery.getResultList();
				        Iterator<Object[]> householdInfoIterator = householdInfoResultList.iterator();
				        Object[] tempInfoResultSet = householdInfoIterator.next();
				        String tempArea = ((GeographicArea) tempInfoResultSet[1]).getName();
				        String tempIncome = ((TotalIncome) tempInfoResultSet[2]).getDescription();
			           	
					    tempOutputTable.add(String.format("%30s", tempArea)
					    		+ String.format("%10s", "@") + String.format("%30s", tempIncome));
					}
		        }
		    );
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempOutputTable;
	}
	public static String GetLargestTotalIncomeGroup(GeographicArea geographicArea, CensusYear censusYear) {

		String tempSQLSelectQuery = "FROM Household h "
				+ "JOIN h.geographicArea ga "
				+ "JOIN h.censusYear cy "
				+ "JOIN h.householdType ht "
				+ "JOIN h.householdSize hs "
				+ "JOIN h.householdsByAgeRange hbar "
				+ "JOIN h.householdEarners he "
				+ "JOIN h.totalIncome ti "
				+ "WHERE ga.alternativeCode = : alternativeCode "
				+ "AND cy.censusYear = : censusYear "
				+ "AND ht.description = : type "
				+ "AND hs.description = : size "
				+ "AND he.description = : earners "
				+ "AND ti.description <> : totalIncome "
				+ "ORDER BY h.numberReported DESC LIMIT 1";
		String tempOutputHousehold = new String();

		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			query.setParameter("alternativeCode", geographicArea.getAlternativeCode());
			query.setParameter("censusYear", censusYear.getCensusYear());
           	query.setParameter("type", "One lone-parent census family without other persons in the household");
           	query.setParameter("size", "2 or more persons");
           	query.setParameter("earners", "1 earner or more");
           	query.setParameter("totalIncome", "Median total income of household ($)");
			Household household = (Household) query.getResultList();
           	
			String tempName = household.getGeographicArea().getName();
			int tempCensusYear = household.getCensusYear().getCensusYear();
			String tempIncomeGroup = household.getTotalIncome().getDescription();
			int tempNumberReports = household.getNumberReported();

			tempOutputHousehold = (String.format("%30s", tempName) + String.format("%10s", ",")
						+ String.format("%10d", tempCensusYear) + String.format("%10s", ",") + String.format("%30s", tempIncomeGroup)
						+ String.format("%10s", ",") + String.format("%15d", tempNumberReports));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempOutputHousehold;
	}
	public static String GetPopulationGrowthByAge(AgeGroup ageGroup) {

		String tempSQLSelectQuery = "FROM Age a "
				+ "JOIN a.geographicArea ga "
				+ "JOIN a.censusYear cy "
				+ "JOIN a.ageGroup ag "
				+ "WHERE ag.ageGroup = : ageGroup ";
		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			query.setParameter("ageGroup", ageGroup);
			List<Age> ageResultList = query.getResultList();
	        Iterator<Age> iterator = ageResultList.iterator();
	        Age resultSet = null;
	        List<String> tempOutputTable = new ArrayList<String>();
	        if (iterator.hasNext()) {
	        	resultSet = iterator.next();
				String tempName = resultSet.getGeographicArea().getName();
				int tempCensusYear = resultSet.getCensusYear().getCensusYear();
				String tempIncomeGroup = resultSet.getTotalIncome().getDescription();
				int tempNumberReports = resultSet.getNumberReported();
	        }

			tempOutputTable = (String.format("%30s", tempName) + String.format("%10s", ",")
						+ String.format("%10d", tempCensusYear) + String.format("%10s", ",") + String.format("%30s", tempIncomeGroup)
						+ String.format("%10s", ",") + String.format("%15d", tempNumberReports));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempOutputTable;
	}
}
