/*
 * FILE         : RegionDetails.java
 * PROJECT      : PROG3060 - Assignment #2
 * PROGRAMMER   : Thomas Craig, Nick Lee, Cynthia Cheng
 * FIRST VERSION: 25/03/2019
 * DESCRIPTION  : This file is used to view details for a specific region
 * 					it takes a region code and level and sets them in the JDBC before 
 * 					retrieving the details from the JDBC and saving them to the session
 * 					and redirecting to the Info page
 */

package prog3060.tcraig;

import java.io.IOException;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ReionDetails", urlPatterns = {"/ReionDetails"})
public class RegionDetails extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	doPost(request,response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        HttpSession tempSession = request.getSession();
        String tempLevel = request.getParameter("level");
        String tempCode = request.getParameter("code");
        String tempAltCode = request.getParameter("altCode");

        JDBCBean.setGeoLevel(tempLevel);
        JDBCBean.setGeoCode(tempCode);
        JDBCBean.setGeoAltCode(tempAltCode);
        List <String> tempDetailsList = JDBCBean.GetRegionDetails();
        tempSession.setAttribute("details", tempDetailsList);
        List <String> tempRegionsBelowList = JDBCBean.GetRegionsBelow();
        tempSession.setAttribute("below", tempRegionsBelowList);
    	response.sendRedirect("./Info.jsp");

    }

}
