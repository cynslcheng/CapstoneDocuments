package prog3060.Bean;

import javax.ejb.Local;

import prog3060.models.CensusYear;
import prog3060.models.GeographicArea;

@Local
public interface LargestTotalIncomeGroupLocal {
	 public String getLargestTotalIncomeGroup(GeographicArea geographicArea, CensusYear censusYear);
}
