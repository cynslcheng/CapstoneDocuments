package prog3060.Bean;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import prog3060.models.CensusYear;
import prog3060.models.GeographicArea;


/**
 * Session Bean implementation class LargestTotalIncomeGroup
 */
@Stateless
@LocalBean
public class LargestTotalIncomeGroup implements LargestTotalIncomeGroupLocal {

    /**
     * Default constructor. 
     */
    public String getLargestTotalIncomeGroup(GeographicArea geographicArea, CensusYear censusYear) {
        String largestTotalIncomeGroup = "";
        
    	return largestTotalIncomeGroup;
    }

}
