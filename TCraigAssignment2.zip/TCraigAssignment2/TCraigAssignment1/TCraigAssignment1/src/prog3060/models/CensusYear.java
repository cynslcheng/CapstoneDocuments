package prog3060.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="CENSUSYEAR", schema="APP")
public class CensusYear {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="CENSUSYEARID", nullable = false)
	private int censusYearID;
    
    @Column(name="CENSUSYEAR", nullable = false)
	private int censusYear;
	
    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Age> ages = new ArrayList<>();
    
    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Household> households = new ArrayList<>();
    
	public CensusYear()
	{}
	
	public int getCensusYearID() {
		return censusYearID;
	}
	public void setCensusYearID(int censusYearID) {
		this.censusYearID = censusYearID;
	}
	
	public int getCensusYear() {
		return censusYear;
	}
	public void setCensusYear(int censusYear) {
		this.censusYear = censusYear;
	}
	

}
