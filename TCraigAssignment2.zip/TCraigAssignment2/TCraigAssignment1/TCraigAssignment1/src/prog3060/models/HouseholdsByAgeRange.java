package prog3060.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="HOUSEHOLDSBYAGERANGE", schema="APP")
public class HouseholdsByAgeRange {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID", nullable = false)
	private int ID;
	
	@Column(name="DESCRIPTION", nullable = false)
	private String description;
	
    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Household> households = new ArrayList<>();
    
    public HouseholdsByAgeRange() {
    	
    }
    
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}