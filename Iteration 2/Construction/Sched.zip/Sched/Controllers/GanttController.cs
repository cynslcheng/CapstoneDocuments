﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Sched.Models;
using System.Threading.Tasks;
using Sched.Attributes;

namespace Sched.Controllers
{
    public class GanttController : Controller
    {
        private SchedContext db = new SchedContext();

        // GET: Gantt
        /// <summary>
        /// OnLoad should display crew, technicians, and resources schedules for the filtered date range and dispatch area
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        public ActionResult _GanttPartial()
        {
            //Prereqs for model
            //1. get date range (if none selected, default to current date)
            DateTime startDateRange = DateTime.Now.AddDays(-7); //temp for testing
            Session["startDate"] = startDateRange;
            DateTime endDateRange = DateTime.Now.AddDays(3); //temp for testings
            Session["endDate"] = endDateRange;
            //2. get dispatch area (if none selected, don't display Gantt chart. 
            //   Display a message please select at least one dispatch area) ? (to reduce load)
            int dispatchAreaId = 1; //temp for testing, need to update for multiple dispatch areas

            //Get database info
            //3. get list of technicians for dispatch area
            List<Technician> allAreaTechnicians = GetAllAreaTechnicians(dispatchAreaId);
            //4. get list of resources for dispatch area
            List<GanttResources> allAreaResources = GetAllAreaResources(dispatchAreaId);
            //5. get list of crews scheduled for date range
            List<Crew> crews = GetAllCrews(dispatchAreaId, startDateRange, endDateRange);
            //6. get list of technicians scheduled for date range and dispatch area
            List<ScheduleTechnicians> scheduledTechnicians = GetScheduleTechnicians(startDateRange, endDateRange, dispatchAreaId);
            //7. get list of resources scheduled for date range and dispatch area
            List<ScheduleResources> scheduledResources = GetScheduleResources(startDateRange, endDateRange, dispatchAreaId);

            //Create Model/gantt list items
            //8. create crewview gantt list
            List<GanttTaskItem> crewTaskList = CreateCrewGanttTaskList(allAreaTechnicians, scheduledTechnicians,
                allAreaResources, scheduledResources, crews, startDateRange, endDateRange);
            //9. combine model as iqueryable tasklists for gantt
            Schedule ScheduleModel = new Schedule { crewViewTaskItems = crewTaskList.AsQueryable() };
            //10. return model
            Session["GanttModel"] = ScheduleModel;

            return PartialView(ScheduleModel);
        }

        /// <summary>
        /// Converts the technician, resources, crews, and schdule lists to format accepted by gantt chart
        /// 
        /// **Requires logic to look into crews over multiple days as resources and technicians may move to new crews
        /// </summary>
        /// <param name="allAreaTechnicians"></param>
        /// <param name="scheduledTechnicians"></param>
        /// <param name="allAreaResources"></param>
        /// <param name="scheduledResources"></param>
        /// <param name="crews"></param>
        /// <returns></returns>
        private List<GanttTaskItem> CreateCrewGanttTaskList(List<Technician> allAreaTechnicians,
            List<ScheduleTechnicians> scheduledTechnicians,
            List<GanttResources> allAreaResources,
            List<ScheduleResources> scheduledResources, List<Crew> crews, DateTime startDateRange, DateTime endDateRange)
        {
            //Create list of gantttaskitems
            List<GanttTaskItem> ganttTaskItems = new List<GanttTaskItem>();

            //Counter to increment pID as not a table in the database
            int counterID = 1;
            //Store parentID for associated technician and resource subtasks
            int crewParentID = 0;
            //Counter variable to display a crew number, visual only and used to not fully expose actual crewID
            int crewCounter = 1;
            //Store technician parentID for technician work orders
            int technicianParentID = 0;
            //Store resource parentID for resource work orders
            int resourceParentID = 0;
            //CrewID to check if moving to a new crew/update parentID to start new task group (deprecated)
            //also used to store in pRes used for gantt chart drag and drop
            int crewID = 0;
            //Store technician and resource Ids for pParent on work orders
            int technicianID = 0;
            int resourceID = 0;
            // To draw multiple work orders on one row
            string dependID = "";

            //If no crews exist ignore crew and work orders code (as no work orders scheduled work orders should exist
            //without a crew based on current ERD
            if (crews.Count != 0)
            {
                //Iterate all scheduled crews
                foreach (Crew crew in crews)
                {
                    crewID = crew.Id;
                    //Create ganttTaskItem with default settings
                    GanttTaskItem ganttCrewTaskItem = new GanttTaskItem
                    {
                        pID = counterID,
                        pName = "Crew #" + crewCounter,
                        pStart = "",
                        pEnd = "",
                        pPlanStart = "",
                        pPlanEnd = "",
                        pClass = "ggroupblack", //status
                        pLink = "",
                        pMile = 0,
                        pRes = "C" + crewID,
                        pComp = 0,
                        pGroup = 1, //1
                        pParent = 0,
                        pOpen = 1,
                        pDepend = "",
                        pCaption = "",
                        pCost = 0,
                        pNotes = "",
                        category = "",
                        sector = ""

                    };
                    //Add crew task to gantt task list
                    ganttTaskItems.Add(ganttCrewTaskItem);
                    //Increment crew counter for next crew
                    crewCounter++;
                    //Save current pID (counterID) for crew technicians and resources
                    crewParentID = counterID;
                    //Increment pID(counterID) for next task
                    counterID++;
                    //Add all scheduled technicians that are in the crew sub tasks
                    foreach (ScheduleTechnicians scheduledTechnician in scheduledTechnicians.Where(x => x.crewId == crewID).ToList())
                    {
                        //create default task to add technician
                        GanttTaskItem technicianTaskItem = new GanttTaskItem
                        {
                            pID = 0,
                            pName = "Default",
                            pStart = "",
                            pEnd = "",
                            pPlanStart = "",
                            pPlanEnd = "",
                            pClass = "gtaskblue",
                            pLink = "",
                            pMile = 0,
                            pRes = "",
                            pComp = 0,
                            pGroup = 2,
                            pParent = crewParentID,
                            pOpen = 1,
                            pDepend = "",
                            pCaption = "",
                            pCost = 0,
                            pNotes = "",
                            category = "",
                            sector = ""
                        };

                        //If first technician or first technician task for crew not yet in gantttasklist
                        if (scheduledTechnician.technicianId != technicianID || technicianID == 0)
                        {
                            //set new counterID as parentID work associated work orders
                            technicianParentID = counterID;
                            //for already on crew task list check
                            technicianID = scheduledTechnician.technicianId;
                            //set technician variables
                            technicianTaskItem.pID = counterID;
                            technicianTaskItem.pName = scheduledTechnician.lastName + ", " + scheduledTechnician.firstName;
                            //Update to pick css with status with case
                            technicianTaskItem.pClass = GetClass(scheduledTechnician.status);
                            technicianTaskItem.pRes = "T" + scheduledTechnician.technicianId;
                            //Add to gantt task items list
                            ganttTaskItems.Add(technicianTaskItem);
                            //Increment pID (counterID) for next gantttaskitem
                            counterID++;
                            //Remove technician from all area list as already in crew
                            Technician technician = allAreaTechnicians.Where(x => x.Id == scheduledTechnician.technicianId).FirstOrDefault();
                            if (technician != null)
                            {
                                allAreaTechnicians.Remove(technician);
                            }
                        }
                        //Create task item for work orders
                        GanttTaskItem workOrderTaskItem = new GanttTaskItem
                        {
                            pID = 0,
                            pName = "Default",
                            pStart = "",
                            pEnd = "",
                            pPlanStart = "",
                            pPlanEnd = "",
                            pClass = "gtaskblue",
                            pLink = "",
                            pMile = 0,
                            pRes = "",
                            pComp = 0,
                            pGroup = 0,
                            pParent = technicianParentID,
                            pOpen = 0,
                            pDepend = "",
                            pCaption = "",
                            pCost = 0,
                            pNotes = "",
                            category = "",
                            sector = ""
                        };
                        //If technician is already on the gantt task list
                        if (scheduledTechnician.technicianId == technicianID)
                        {
                            //Set work order task item data
                            workOrderTaskItem.pID = counterID;
                            workOrderTaskItem.pName = "Work Order #: " + scheduledTechnician.workOrderId.ToString();
                            workOrderTaskItem.pStart = scheduledTechnician.startTime.ToString("yyyy'-'MM'-'dd HH:mm");
                            workOrderTaskItem.pEnd = scheduledTechnician.endTime.ToString("yyyy'-'MM'-'dd HH:mm");
                            workOrderTaskItem.pPlanStart = scheduledTechnician.startTime.ToString("yyyy'-'MM'-'dd HH:mm"); //2013-02-20 09:00
                            workOrderTaskItem.pPlanEnd = scheduledTechnician.endTime.ToString("yyyy'-'MM'-'dd HH:mm");
                            //Update to pick css with status - call function
                            workOrderTaskItem.pClass = GetClass(scheduledTechnician.status);
                            //Add removal link with pLink
                            workOrderTaskItem.pLink = "Display/CancelTechnician?workOrderId=" + scheduledTechnician.workOrderId +
                                "&technicianId=" + scheduledTechnician.technicianId;
                            workOrderTaskItem.pRes = "WO" + scheduledTechnician.workOrderId.ToString();
                            if (dependID != "")
                            {
                                workOrderTaskItem.pDepend = dependID;
                            }
                            dependID = counterID.ToString();
                            //Add to gantt task items list
                            ganttTaskItems.Add(workOrderTaskItem);
                            //Increment pID(counterID) for next gantttaskitem
                            counterID++;
                        }

                    }
                    dependID = "";
                    //Add all scheduled resources that are in the crew sub tasks
                    foreach (ScheduleResources scheduledResource in scheduledResources.Where(x => x.crewId == crewID).ToList())
                    {
                        GanttTaskItem resourceTaskItem = new GanttTaskItem
                        {
                            pID = 0,
                            pName = "Default",
                            pStart = "",
                            pEnd = "",
                            pPlanStart = "",
                            pPlanEnd = "",
                            pClass = "gtaskgreen",
                            pLink = "",
                            pMile = 0,
                            pRes = "",
                            pComp = 0,
                            pGroup = 2,
                            pParent = crewParentID,
                            pOpen = 1,
                            pDepend = "",
                            pCaption = "",
                            pCost = 0,
                            pNotes = "",
                            category = "",
                            sector = ""
                        };
                        //If first resource or resource not yet on gantttasklist
                        if (scheduledResource.resourceId != resourceID || resourceID == 0)
                        {
                            resourceParentID = counterID;
                            //set resourceID to add work orders
                            resourceID = scheduledResource.resourceId;

                            resourceTaskItem.pID = counterID;
                            resourceTaskItem.pName = scheduledResource.name + "#" + scheduledResource.resourceId;
                            resourceTaskItem.pStart = "";
                            resourceTaskItem.pEnd = "";
                            resourceTaskItem.pPlanStart = "";
                            resourceTaskItem.pPlanEnd = "";
                            //Update to pick css with status with case
                            //resourceTaskItem.pClass = GetClass(scheduledResource.status);
                            //Add removal link with pLink - call function
                            //ganttTaskItem.pLink
                            resourceTaskItem.pRes = "R" + scheduledResource.resourceId;
                            //Add to gantt task items list
                            ganttTaskItems.Add(resourceTaskItem);
                            counterID++;
                            //Remove resource from all area list as already in crew
                            GanttResources resource = allAreaResources.Where(r => r.Id == resourceID).FirstOrDefault();
                            if (resource != null)
                            {
                                allAreaResources.Remove(resource);
                            }
                        }
                        GanttTaskItem workOrderTaskItem = new GanttTaskItem
                        {
                            pID = 0,
                            pName = "Default",
                            pStart = "",
                            pEnd = "",
                            pPlanStart = "",
                            pPlanEnd = "",
                            pClass = "gtaskblue",
                            pLink = "",
                            pMile = 0,
                            pRes = "",
                            pComp = 0,
                            pGroup = 0, //2
                            pParent = resourceParentID,
                            pOpen = 0,
                            pDepend = "",
                            pCaption = "",
                            pCost = 0,
                            pNotes = "",
                            category = "",
                            sector = ""
                        };
                        //if technician is already on the gantt task list
                        if (scheduledResource.resourceId == resourceID)
                        {
                            workOrderTaskItem.pID = counterID;
                            workOrderTaskItem.pName = "Work Order ID:" + scheduledResource.workOrderId.ToString();
                            workOrderTaskItem.pStart = scheduledResource.startTime.ToString("yyyy'-'MM'-'dd HH:mm");
                            workOrderTaskItem.pEnd = scheduledResource.endTime.ToString("yyyy'-'MM'-'dd HH:mm");
                            workOrderTaskItem.pPlanStart = scheduledResource.startTime.ToString("yyyy'-'MM'-'dd HH:mm");
                            workOrderTaskItem.pPlanEnd = scheduledResource.endTime.ToString("yyyy'-'MM'-'dd HH:mm");
                            //Update to pick css with status - call function
                            workOrderTaskItem.pClass = GetClass(scheduledResource.status);
                            //Add removal link with pLink
                            workOrderTaskItem.pLink = "Display/CancelResource?workOrderId=" + scheduledResource.workOrderId +
                                "&resourceId=" + scheduledResource.resourceId;
                            workOrderTaskItem.pRes = "WO" + scheduledResource.workOrderId.ToString();
                            if (dependID != "")
                            {
                                workOrderTaskItem.pDepend = dependID;
                            }
                            dependID = counterID.ToString();
                            //Add to gantt task items list
                            ganttTaskItems.Add(workOrderTaskItem);
                            counterID++;
                        }
                    }
                }
                //reset technicianID, resourceID, and dependID for next crew
                technicianID = 0;
                resourceID = 0;
                dependID = "";
            }

            //Ignore if no unscheduled area technicians
            if (allAreaTechnicians.Count != 0)
            {
                foreach (Technician technician in allAreaTechnicians)
                {
                    //add unscheduled technician to ganttTaskItems as top level tasks
                    GanttTaskItem technicianTaskItem = new GanttTaskItem
                    {
                        pID = counterID,
                        pName = technician.last_name + ", " + technician.first_name,
                        pStart = "",
                        pEnd = "",
                        pPlanStart = "",
                        pPlanEnd = "",
                        pClass = "gtaskblue",
                        pLink = "",
                        pMile = 0,
                        pRes = "T" + technician.Id,
                        pComp = 0,
                        pGroup = 1,
                        pParent = 0,
                        pOpen = 1, //0
                        pDepend = "",
                        pCaption = "",
                        pCost = 0,
                        pNotes = "",
                        category = "",
                        sector = ""
                    };
                    //Add to gantt task items list
                    ganttTaskItems.Add(technicianTaskItem);
                    counterID++;
                }
            }
            //Ignore if no unscheduled area resources
            if (allAreaResources.Count != 0)
            {
                foreach (GanttResources resource in allAreaResources)
                {
                    //Add unscheduled resources to ganttTaskItems as top level tasks
                    GanttTaskItem resourceTaskItem = new GanttTaskItem
                    {
                        pID = counterID,
                        pName = resource.name + " #" + resource.Id.ToString(),
                        pStart = "",
                        pEnd = "",
                        pPlanStart = "",
                        pPlanEnd = "",
                        pClass = "gtaskred",
                        pLink = "",
                        pMile = 0,
                        pRes = "R" + resource.Id,
                        pComp = 0,
                        pGroup = 1,
                        pParent = 0,
                        pOpen = 1, //0
                        pDepend = "",
                        pCaption = "",
                        pCost = 0,
                        pNotes = "",
                        category = "",
                        sector = ""
                    };

                    //Add to gantt task items list
                    ganttTaskItems.Add(resourceTaskItem);
                    counterID++;
                }
            }
            //Add task for entire date range, enables being able to see all dates that are desired for scheduling
            GanttTaskItem ganttDateTaskItem = new GanttTaskItem
            {
                pID = counterID,
                pName = "<strong>Dates: " + startDateRange.ToString("yyyy'-'MM'-'dd") + " to " + endDateRange.ToString("yyyy'-'MM'-'dd") + "</strong>",
                pStart = startDateRange.ToString("yyyy'-'MM'-'dd"),
                pEnd = endDateRange.ToString("yyyy'-'MM'-'dd"),
                pPlanStart = startDateRange.ToString("yyyy'-'MM'-'dd"),
                pPlanEnd = endDateRange.ToString("yyyy'-'MM'-'dd"),
                pClass = "ggroupblack",
                pLink = "",
                pMile = 0,
                pRes = "",
                pComp = 0,
                pGroup = 0,
                pParent = 0,
                pOpen = 1,
                pDepend = "",
                pCaption = "",
                pCost = 0,
                pNotes = "",
                category = "",
                sector = ""
            };
            ganttTaskItems.Add(ganttDateTaskItem);

            ganttTaskItems = ganttTaskItems.OrderBy(x => x.pID).ToList();

            return ganttTaskItems;
        }

        /// <summary>
        /// Determine what colour for work order task bar based on status
        /// </summary>
        /// <param name="status">status name</param>
        /// <returns>css class for task bar colour</returns>
        private string GetClass(string status)
        {
            switch (status)
            {
                case "dispatched":
                    return "gtaskgreen";
                case "BAPP":
                    return "gtaskgreen";
                case "NFA":
                    return "gtaskpink";
                case "ACK":
                    return "gtaskblue";
                case "DIS":
                    return "gtaskgreen";
                case "Enroute":
                    return "gtaskblue";
                case "OnSite":
                    return "gtaskpurple";
                case "Suspended":
                    return "gtaskyellow";
                default:
                    return "ggroupblack";
            }
        }

        /// <summary>
        /// Gets scheduled resources for dispatcher requested start to end date range and selected dispatch area
        /// </summary>
        /// <param name="startDateRange">earliest date for scheduling</param>
        /// <param name="endDateRange">latest date for scheduling</param>
        /// <param name="dispatchAreaId">dispatch area to schedule for</param>
        /// <returns></returns>
        private List<ScheduleResources> GetScheduleResources(DateTime startDateRange,
            DateTime endDateRange,
            int dispatchAreaId)
        {
            List<ScheduleResources> scheduledResources = db.WorkOrder
                .Join(db.status, wo => wo.status_id, s => s.Id, (wo, s) => new { workOrders = wo, statuses = s })
                .Join(db.workArea, wo1 => wo1.workOrders.work_area_id, wa => wa.Id, (wo1, wa) => new { firstJoin = wo1, workArea = wa })
                .Join(db.job, wo2 => wo2.firstJoin.workOrders.Id, j => j.Id, (wo2, j) => new { secondJoin = wo2, jobs = j })
                .Join(db.jobCrew, wo3 => wo3.jobs.Id, jc => jc.jobId, (wo3, jc) => new { thirdJoin = wo3, jobcrews = jc })
                .Join(db.crew, wo4 => wo4.jobcrews.crewId, c => c.Id, (wo4, c) => new { fourthJoin = wo4, crews = c })
                .Join(db.crew_resources, wo5 => wo5.crews.Id, cr => cr.crewID, (wo5, cr) => new { fifthJoin = wo5, crewResources = cr })
                .Join(db.resources, wo6 => wo6.crewResources.resourcesid, r => r.Id, (wo6, r) => new { sixthJoin = wo6, resources = r })
                .Join(db.resourcesTypes, wo7 => wo7.resources.Id, rt => rt.Id, (wo7, rt) => new { seventhJoin = wo7, resourceTypes = rt })
                .Where(w => ((w.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time >= startDateRange
                    && w.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time < endDateRange)
                    || (w.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time > startDateRange
                    && w.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time <= endDateRange)
                    || (w.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time <= startDateRange
                    && w.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time >= endDateRange))
                    && w.seventhJoin.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.workArea.Id == dispatchAreaId)
                 .Select(s => new ScheduleResources
                 { 
                     resourceId = s.seventhJoin.resources.Id,
                     name = s.resourceTypes.name,
                     startTime = s.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time,
                     endTime = s.seventhJoin.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time,
                     workOrderDesiredMinTime = s.seventhJoin.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.workOrders.minimum_start_time,
                     workOrderDesiredMaxTime = s.seventhJoin.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.workOrders.maximum_start_time,
                     status = s.seventhJoin.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.statuses.name,
                     workOrderId = s.seventhJoin.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.workOrders.Id,
                     crewId = s.seventhJoin.sixthJoin.crewResources.crewID
                 })
                 .OrderBy(o => o.resourceId)
                 .ToList();
            return scheduledResources;
        }

        private List<ScheduleTechnicians> GetScheduleTechnicians(DateTime startDateRange,
            DateTime endDateRange,
            int dispatchAreaId)
        {
            List<ScheduleTechnicians> scheduledTechnicians = db.WorkOrder
                .Join(db.status, wo => wo.status_id, s => s.Id, (wo, s) => new { workOrders = wo, statuses = s })
                .Join(db.workArea, wo1 => wo1.workOrders.work_area_id, wa => wa.Id, (wo1, wa) => new { firstJoin = wo1, workArea = wa })
                .Join(db.job, wo2 => wo2.firstJoin.workOrders.Id, j => j.Id, (wo2, j) => new { secondJoin = wo2, jobs = j })
                .Join(db.jobCrew, wo3 => wo3.jobs.Id, jc => jc.jobId, (wo3, jc) => new { thirdJoin = wo3, jobcrews = jc })
                .Join(db.crew, wo4 => wo4.jobcrews.crewId, c => c.Id, (wo4, c) => new { fourthJoin = wo4, crews = c })
                .Join(db.crew_technician, wo5 => wo5.crews.Id, ct => ct.crewid, (wo5, ct) => new { fifthJoin = wo5, crewTechnicians = ct })
                .Join(db.technician, wo6 => wo6.crewTechnicians.technicianid, t => t.Id, (wo6, t) => new { sixthJoin = wo6, technicians = t })
                .Where(w => ((w.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time >= startDateRange
                    && w.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time < endDateRange)
                    || (w.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time > startDateRange
                    && w.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time < endDateRange)
                    || (w.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time <= startDateRange
                    && w.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time <= endDateRange))
                    && w.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.workArea.Id == dispatchAreaId)
                 .Select(s => new ScheduleTechnicians
                 {
                     technicianId = s.technicians.Id,
                     firstName = s.technicians.first_name,
                     lastName = s.technicians.last_name,
                     startTime = s.sixthJoin.fifthJoin.fourthJoin.jobcrews.start_time,
                     endTime = s.sixthJoin.fifthJoin.fourthJoin.jobcrews.end_time,
                     workOrderDesiredMinTime = s.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.workOrders.minimum_start_time,
                     workOrderDesiredMaxTime = s.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.workOrders.maximum_start_time,
                     status = s.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.statuses.name,
                     workOrderId = s.sixthJoin.fifthJoin.fourthJoin.thirdJoin.secondJoin.firstJoin.workOrders.Id,
                     crewId = s.sixthJoin.crewTechnicians.crewid
                 })
                 .OrderBy(o => o.technicianId)
                 .ToList();
            return scheduledTechnicians;
        }

        private List<Crew> GetAllCrews(int dispatchAreaId, DateTime startDateRange, DateTime endDateRange)
        {
            List<Crew> crews = db.crew.Where(c =>
                ((c.start_Time >= startDateRange && c.start_Time < endDateRange)
                || (c.end_Time > startDateRange && c.end_Time <= endDateRange)
                || (c.start_Time <= startDateRange && c.end_Time >= endDateRange)) && c.work_area_id == dispatchAreaId)
                .ToList();
            return crews;
        }

        private List<GanttResources> GetAllAreaResources(int dispatchAreaId)
        {
            List<GanttResources> resources = db.resources
                .Join(db.resourcesTypes, r => r.resource_type, rt => rt.Id, (r, rt) => new { resource = r, resourceType = rt })
                .Where(r => r.resource.work_area_id == dispatchAreaId)
                .Select(s => new GanttResources
                {
                    Id = s.resource.Id,
                    resource_type = s.resourceType.Id,
                    name = s.resourceType.name,
                    work_area_id = s.resource.work_area_id
                })
                .OrderBy(o => o.Id)
                .ToList();
            return resources;
        }

        private List<Technician> GetAllAreaTechnicians(int dispatchAreaId)
        {
            List<Technician> technicians = db.technician.Where(t => t.work_area_Id == dispatchAreaId).ToList();
            return technicians;
        }

        [HttpPost]
        public ActionResult AddTaskItem(string proposedTime, string resourceTechId,string workOrderId)
        {
            //return RedirectToAction("_GanttPartial");
            Schedule schedule = (Schedule)Session["GanttModel"];
            DateTime insertDate = DateTime.Now;
            int workOrderIdNum = Convert.ToInt32(workOrderId);
           // resourceTechId = "R1";
            WorkOrder workOrder = db.WorkOrder.Where(x => x.Id == workOrderIdNum).First();
            List<GanttTaskItem> ganttTaskItems = schedule.crewViewTaskItems.ToList();
            //get last pID in ganttTaskItems and increment for new gant task item
            int pID = ganttTaskItems.Last().pID + 1;
            GanttTaskItem taskItem = new GanttTaskItem();
            if (resourceTechId.Contains("R"))
            {
                int resourceId = Convert.ToInt32(resourceTechId.Substring(1));
                Resources resource = db.resources.Where(x => x.Id == resourceId).First();
                GanttTaskItem ganttTaskItem = ganttTaskItems.Where(x => x.pRes.Contains(resourceTechId)).FirstOrDefault();
                int resourcepID = ganttTaskItem.pID;
                //below to be used in depend
                //int precedingWorkOrderPID = ganttTaskItems.Where(x => x.pParent == resourcepID && DateTime.(x.pEnd) < insertDate).
                taskItem.pID = pID;
                taskItem.pParent = resourcepID;
                taskItem.pName = "Work Order ID:" + workOrderId;
                taskItem.pPlanStart = insertDate.ToString("yyyy'-'MM'-'dd");
                taskItem.pStart = insertDate.ToString("yyyy'-'MM'-'dd");
                taskItem.pPlanEnd = insertDate.AddMinutes(workOrder.estimated_time_minutes).ToString("yyyy'-'MM'-'dd");
                taskItem.pEnd = insertDate.AddMinutes(workOrder.estimated_time_minutes).ToString("yyyy'-'MM'-'dd");
                string status = db.status.Where(x => x.Id == workOrder.status_id).First().name;

                taskItem.pClass = GetClass(status);
                taskItem.pGroup = 0;
                taskItem.pLink = "Display/CancelResource?workOrderId=" + workOrder.Id.ToString() + "&resourceId=" + resourceId;
                taskItem.pMile = 0;
                taskItem.pRes = "Work Order ID:" + workOrder.Id.ToString();
                taskItem.pOpen = 0;
                taskItem.pDepend = ""; //put preceding id here
                taskItem.pCost = 0;
                taskItem.pNotes = "";
                taskItem.category = "";
                taskItem.sector = "";
                taskItem.pCaption = "";
               
                ganttTaskItems.Add(taskItem);
                schedule.crewViewTaskItems = ganttTaskItems.AsQueryable();

            }
            else
            {
                int techId = Convert.ToInt32(resourceTechId.Substring(1));
                Technician technician = db.technician.Where(x => x.Id == techId).First();
                GanttTaskItem ganttTaskItem = ganttTaskItems.Where(x => x.pRes.Contains(resourceTechId)).FirstOrDefault();
                int technicianPID = ganttTaskItem.pID;//ganttTaskItem.pID;
                taskItem.pID = pID;
                taskItem.pParent = technicianPID;
                taskItem.pName = "Work Order ID:" + workOrderId;
                taskItem.pPlanStart = insertDate.ToString("yyyy'-'MM'-'dd");
                taskItem.pStart = insertDate.ToString("yyyy'-'MM'-'dd");
                taskItem.pPlanEnd = insertDate.AddMinutes(workOrder.estimated_time_minutes).ToString("yyyy'-'MM'-'dd");
                taskItem.pEnd = insertDate.AddMinutes(workOrder.estimated_time_minutes).ToString("yyyy'-'MM'-'dd");
                string status = db.status.Where(x => x.Id == workOrder.status_id).First().name;

                taskItem.pClass = GetClass(status);
                taskItem.pGroup = 0;
                taskItem.pLink = "";
                taskItem.pMile = 0;
                taskItem.pRes = resourceTechId;
                taskItem.pOpen = 1;
                taskItem.pDepend = ""; //put preceding id here
                taskItem.pCost = 0;
                taskItem.pNotes = "";
                taskItem.category = "";
                taskItem.sector = "";
                taskItem.pCaption = "";
                ganttTaskItems.Add(taskItem);
                schedule.crewViewTaskItems = ganttTaskItems.AsQueryable();
            }
            Session["GanttModel"] = schedule;
            return PartialView("_GanttPartial", schedule);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
