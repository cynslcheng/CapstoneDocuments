﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sched.Models
{
    public class Schedule
    {
        public IQueryable<GanttTaskItem> crewViewTaskItems { get; set; }
    }

    public class GanttTaskItem
    {
        public int pID { get; set; } //need
        public string pName { get; set; } //need
        public string pStart { get; set; } //2017-02-25 need
        public string pEnd { get; set; }  //need
        public string pPlanStart { get; set; }
        public string pPlanEnd { get; set; }
        public string pClass { get; set; } //css styling i.e. ggroupblack 
        public string pLink { get; set; } //maybe delete functionality
        public int pMile { get; set; } //always set to 0
        public string pRes { get; set; }
        public int pComp { get; set; }
        public int pGroup { get; set; } //0 - normal task, 1 standard group, 2 combined group
        public int pParent { get; set; } //crew id
        public int pOpen { get; set; }
        public string pDepend { get; set; }
        public string pCaption { get; set; }
        public float pCost { get; set; }
        public string pNotes { get; set; } //put work order details here?
        public string category { get; set; }
        public string sector { get; set; }
    }

    public class ScheduleResources
    {
        public int resourceId { get; set; }
        public string name { get; set; }
        public DateTime startTime { get; set; }
        public DateTime endTime { get; set; }
        public DateTime workOrderDesiredMinTime { get; set; }
        public DateTime workOrderDesiredMaxTime { get; set; }
        public string status { get; set; }
        public int workOrderId { get; set; }
        public int crewId { get; set; }
    }

    public class ScheduleTechnicians
    {
        public int technicianId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public DateTime startTime { get; set; }
        public DateTime endTime { get; set; }
        public DateTime workOrderDesiredMinTime { get; set; }
        public DateTime workOrderDesiredMaxTime { get; set; }
        public string status { get; set; }
        public int workOrderId { get; set; }
        public int crewId { get; set; }
    }

    public class GanttResources
    {
        public int Id { get; set; }
        public int resource_type { get; set; }
        public int work_area_id { get; set; }
        public string name { get; set; }
    }
}