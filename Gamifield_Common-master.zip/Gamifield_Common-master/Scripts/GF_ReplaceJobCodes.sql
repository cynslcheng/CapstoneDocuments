-- Replace Job Codes for existing jobs

--select distinct JobCode From vw_UTP_WO
--select * From vw_UTP_WO
--select * From vw_CAT_JobPlanT

update UTP_WO set JobCodeID = 1100001 where OrderID in (select OrderID from vw_UTP_WO where JobCode=' / ')
update UTP_WO set JobCodeID = 1100002 where OrderID in (select OrderID from vw_UTP_WO where JobCode='CSMO / PFMSTATION')
update UTP_WO set JobCodeID = 1100003 where OrderID in (select OrderID from vw_UTP_WO where JobCode='DSOF / TURNOFF')
update UTP_WO set JobCodeID = 1100004 where OrderID in (select OrderID from vw_UTP_WO where JobCode='F INSPECT / ')
update UTP_WO set JobCodeID = 1100005 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MMCC / REBUILD')
update UTP_WO set JobCodeID = 1100006 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MODC / OOD')
update UTP_WO set JobCodeID = 1100008 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MODR / OOD')
update UTP_WO set JobCodeID = 1100009 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MREG / REPLACEREG')
update UTP_WO set JobCodeID = 1100010 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MSMA / MANIFOLD')
update UTP_WO set JobCodeID = 1100011 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MSMR / BLUE TAG')
update UTP_WO set JobCodeID = 1100012 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MSRS / BLUETAG')
update UTP_WO set JobCodeID = 1100013 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MTCR / TURNON')
update UTP_WO set JobCodeID = 1100014 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MXGI / OOD')
update UTP_WO set JobCodeID = 1100005 where OrderID in (select OrderID from vw_UTP_WO where JobCode='MXGI / SAMPLE')
update UTP_WO set JobCodeID = 1100006 where OrderID in (select OrderID from vw_UTP_WO where JobCode='NBKU / NEWSET')
update UTP_WO set JobCodeID = 1100008 where OrderID in (select OrderID from vw_UTP_WO where JobCode='RNEW / TIEOVER')

delete From UTP_Spec where AttributeName='JobType'
delete From UTP_Spec where AttributeName='JobCode'

/*
-- Mapping


' / '			STN / STNPI / STNPI
'CSMO / PFMSTATION'			STN / DISTSTN / TUBING
'DSOF / TURNOFF'			STN / HEADSTN / FH
'F INSPECT / '			STN / HEADSTN / FHH
'MMCC / REBUILD'			STN / HEADSTN / FHH3
'MODC / OOD'			STN / SALESTN / FSH2
'MODR / OOD'			STN / FARMTAP / EG40450F
'MREG / REPLACEREG'			STN / STNMTO / FMOB
'MSMA / MANIFOLD'			PIPE / HEADSTN / IH
'MSMR / BLUE TAG'			PIPE / HEADSTN / IHH
'MSRS / BLUETAG'			PIPE / HEADSTN / IHT
'MTCR / TURNON'			PIPE / SALESTN / IP2
'MXGI / OOD'			PIPE / STNMTO / IMOB
'MXGI / SAMPLE'			STN / HEADSTN / FHH3
'NBKU / NEWSET'			STN / FARMTAP / EG40450F
'RNEW / TIEOVER'			STN / STNMTO / FMOB

*/













