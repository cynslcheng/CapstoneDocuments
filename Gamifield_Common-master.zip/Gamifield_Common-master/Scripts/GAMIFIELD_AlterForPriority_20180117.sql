alter table UTP_WO
	ADD WOPriority int not null default 5
GO

