--
-- Feb 15, 2019
-- Create Job Codes for Gamifield DB
--
---------------------------------------------------------
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11000,'EGD_WORKTYPE','STN','Station','Station',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11001,'EGD_WORKTYPE','PIPE','Pipe','Pipe',0,1
---------------------------------------------------------
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11002,'EGD_WAMS_SUBTYPE','STNPI ','Piping','Piping',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11003,'EGD_WAMS_SUBTYPE','DISTSTN ','Dist Stn','Dist Stn',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11004,'EGD_WAMS_SUBTYPE','HEADSTN ','Head Stn','Head Stn',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11005,'EGD_WAMS_SUBTYPE','SALESTN ','Sales Stn','Sales Stn',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11006,'EGD_WAMS_SUBTYPE','FARMTAP ','Farm Tap','Farm Tap',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11007,'EGD_WAMS_SUBTYPE','STNMTO ','Stn MTO','Stn MTO',0,1
---------------------------------------------------------
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11008,'EGD_JPNUM','STNPI','Station Piping','Station Piping',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11009,'EGD_JPNUM','TUBING','Station Tubing','Station Tubing',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11010,'EGD_JPNUM','FH','Free Heat','Free Heat',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11011,'EGD_JPNUM','FHH','FHH','FHH',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11012,'EGD_JPNUM','FHH3','FHH3','FHH3',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11013,'EGD_JPNUM','FSH2','FSH2','FSH2',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11014,'EGD_JPNUM','FSH3','FSH3','FSH3',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11015,'EGD_JPNUM','EG40450F','EG40450F','EG40450F',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11016,'EGD_JPNUM','FMOB','Mobile','Mobile',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11017,'EGD_JPNUM','IH','IH','IH',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11018,'EGD_JPNUM','IHH','IHH','IHH',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11019,'EGD_JPNUM','IHT','IHT','IHT',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11020,'EGD_JPNUM','IP2','IH2','IH2',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11021,'EGD_JPNUM','IMOB','IMobile','IMobile',0,1

---------------------------------------------------------

insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11100,'CAT_Template','TM_STN / STNPI / STNPI','TM_STN / STNPI / STNPI','TM_STN / STNPI / STNPI',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11101,'CAT_Template','TM_STN / DISTSTN / TUBING','TM_STN / DISTSTN / TUBING','TM_STN / DISTSTN / TUBING',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11102,'CAT_Template','TM_STN / HEADSTN / FH','TM_STN / HEADSTN / FH','TM_STN / HEADSTN / FH',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11103,'CAT_Template','TM_STN / HEADSTN / FHH','TM_STN / HEADSTN / FHH','TM_STN / HEADSTN / FHH',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11104,'CAT_Template','TM_STN / HEADSTN / FHH3','TM_STN / HEADSTN / FHH3','TM_STN / HEADSTN / FHH3',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11105,'CAT_Template','TM_STN / SALESTN / FSH2','TM_STN / SALESTN / FSH2','TM_STN / SALESTN / FSH2',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11106,'CAT_Template','TM_STN / SALESTN / FSH3','TM_STN / SALESTN / FSH3','TM_STN / SALESTN / FSH3',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11107,'CAT_Template','TM_STN / FARMTAP / EG40450F','TM_STN / FARMTAP / EG40450F','TM_STN / FARMTAP / EG40450F',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11108,'CAT_Template','TM_STN / STNMTO / FMOB','TM_STN / STNMTO / FMOB','TM_STN / STNMTO / FMOB',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11109,'CAT_Template','TM_PIPE / HEADSTN / IH','TM_PIPE / HEADSTN / IH','TM_PIPE / HEADSTN / IH',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11110,'CAT_Template','TM_PIPE / HEADSTN / IHH','TM_PIPE / HEADSTN / IHH','TM_PIPE / HEADSTN / IHH',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11111,'CAT_Template','TM_PIPE / HEADSTN / IHT','TM_PIPE / HEADSTN / IHT','TM_PIPE / HEADSTN / IHT',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11112,'CAT_Template','TM_PIPE / SALESTN / IP2','TM_PIPE / SALESTN / IP2','TM_PIPE / SALESTN / IP2',0,1
insert UTP_ListMaster (ListID,ListKey,ListValue,ListText,HelpText,IsDefault,IsActive) select 11113,'CAT_Template','TM_PIPE / STNMTO / IMOB','TM_PIPE / STNMTO / IMOB','TM_PIPE / STNMTO / IMOB',0,1

---------------------------------------------------------

exec CAT_NewJobCode 1100001,6,'STN','STNPI','STNPI',@Note='TestData',@PrimaryTemplate='TM_STN / STNPI / STNPI'
exec CAT_NewJobCode 1100002,6,'STN','DISTSTN','TUBING',@Note='TestData',@PrimaryTemplate='TM_STN / DISTSTN / TUBING'
exec CAT_NewJobCode 1100003,6,'STN','HEADSTN','FH',@Note='TestData',@PrimaryTemplate='TM_STN / HEADSTN / FH'
exec CAT_NewJobCode 1100004,6,'STN','HEADSTN','FHH',@Note='TestData',@PrimaryTemplate='TM_STN / HEADSTN / FHH'
exec CAT_NewJobCode 1100005,6,'STN','HEADSTN','FHH3',@Note='TestData',@PrimaryTemplate='TM_STN / HEADSTN / FHH3'
exec CAT_NewJobCode 1100006,6,'STN','SALESTN','FSH2',@Note='TestData',@PrimaryTemplate='TM_STN / SALESTN / FSH2'
exec CAT_NewJobCode 1100007,6,'STN','SALESTN','FSH3',@Note='TestData',@PrimaryTemplate='TM_STN / SALESTN / FSH3'
exec CAT_NewJobCode 1100008,6,'STN','FARMTAP','EG40450F',@Note='TestData',@PrimaryTemplate='TM_STN / FARMTAP / EG40450F'
exec CAT_NewJobCode 1100009,6,'STN','STNMTO','FMOB',@Note='TestData',@PrimaryTemplate='TM_STN / STNMTO / FMOB'
exec CAT_NewJobCode 1100010,6,'PIPE','HEADSTN','IH',@Note='TestData',@PrimaryTemplate='TM_PIPE / HEADSTN / IH'
exec CAT_NewJobCode 1100011,6,'PIPE','HEADSTN','IHH',@Note='TestData',@PrimaryTemplate='TM_PIPE / HEADSTN / IHH'
exec CAT_NewJobCode 1100012,6,'PIPE','HEADSTN','IHT',@Note='TestData',@PrimaryTemplate='TM_PIPE / HEADSTN / IHT'
exec CAT_NewJobCode 1100013,6,'PIPE','SALESTN','IP2',@Note='TestData',@PrimaryTemplate='TM_PIPE / SALESTN / IP2'
exec CAT_NewJobCode 1100014,6,'PIPE','STNMTO','IMOB',@Note='TestData',@PrimaryTemplate='TM_PIPE / STNMTO / IMOB'




update CAT_JobCode set ExpectedDuration=90 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / STNPI / STNPI')
update CAT_JobCode set ExpectedDuration=90 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / DISTSTN / TUBING')
update CAT_JobCode set ExpectedDuration=90 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / HEADSTN / FH')
update CAT_JobCode set ExpectedDuration=90 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / HEADSTN / FHH')
update CAT_JobCode set ExpectedDuration=90 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / HEADSTN / FHH3')
update CAT_JobCode set ExpectedDuration=120 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / SALESTN / FSH2')
update CAT_JobCode set ExpectedDuration=120 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / SALESTN / FSH3')
update CAT_JobCode set ExpectedDuration=120 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / FARMTAP / EG40450F')
update CAT_JobCode set ExpectedDuration=30 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='STN / STNMTO / FMOB')
update CAT_JobCode set ExpectedDuration=75 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='PIPE / HEADSTN / IH')
update CAT_JobCode set ExpectedDuration=75 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='PIPE / HEADSTN / IHH')
update CAT_JobCode set ExpectedDuration=360 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='PIPE / HEADSTN / IHT')
update CAT_JobCode set ExpectedDuration=90 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='PIPE / SALESTN / IP2')
update CAT_JobCode set ExpectedDuration=45 where JobCodeID in (select JobCodeID from vw_CAT_JobPlanT where JobCode='PIPE / STNMTO / IMOB')

update CAT_JobCode set AllowEarlyArrival=1 where JobCodeID in (select JobCodeID from  vw_CAT_JobPlanT where JobCode in(
	'STN / STNPI / STNPI',
	'STN / DISTSTN / TUBING',
	'STN / HEADSTN / FH',
	'STN / HEADSTN / FHH',
	'STN / HEADSTN / FHH3',
	'STN / SALESTN / FSH2',
	'STN / SALESTN / FSH3',
	'PIPE / HEADSTN / IHT',
	'PIPE / SALESTN / IP2',
	'PIPE / STNMTO / IMOB')
)

exec CAT_NewJobCodeList 'STN','STNPI','STNPI','10'
exec CAT_NewJobCodeList 'STN','DISTSTN','TUBING','10'
exec CAT_NewJobCodeList 'STN','HEADSTN','FH','10'
exec CAT_NewJobCodeList 'STN','HEADSTN','FHH','10'
exec CAT_NewJobCodeList 'STN','HEADSTN','FHH3','10'
exec CAT_NewJobCodeList 'STN','SALESTN','FSH2','10'
exec CAT_NewJobCodeList 'STN','SALESTN','FSH3','10'
exec CAT_NewJobCodeList 'STN','FARMTAP','EG40450F','10'
exec CAT_NewJobCodeList 'STN','STNMTO','FMOB','10'
exec CAT_NewJobCodeList 'PIPE','HEADSTN','IH','10'
exec CAT_NewJobCodeList 'PIPE','HEADSTN','IHH','10'
exec CAT_NewJobCodeList 'PIPE','HEADSTN','IHT','10'
exec CAT_NewJobCodeList 'PIPE','SALESTN','IP2','10'
exec CAT_NewJobCodeList 'PIPE','STNMTO','IMOB','10'

exec CAT_NewJobCodeList 'PIPE','HEADSTN','IH','99'
exec CAT_NewJobCodeList 'PIPE','HEADSTN','IHH','99'
exec CAT_NewJobCodeList 'PIPE','HEADSTN','IHT','99'
exec CAT_NewJobCodeList 'PIPE','SALESTN','IP2','99'
exec CAT_NewJobCodeList 'PIPE','STNMTO','IMOB','99'


