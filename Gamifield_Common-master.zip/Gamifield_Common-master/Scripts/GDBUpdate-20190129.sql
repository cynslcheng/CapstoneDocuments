/*
	Updates to Base DEV_GAMIFIELD database for second prototype
*/
/*
	GWS_GetListMaster
	Returns List Master entries to GAMIFIELDWS
	Created - 2019-01-17 by IDM
*/
ALTER PROCEDURE [dbo].[GWS_GetListMaster]
	@ListID int = NULL,
	@Key varchar(255) = NULL
AS
	IF @ListID IS NOT NULL
	BEGIN
		SELECT ListID,ListKey,ListValue,ListText,HelpText,IsDefault,SortOrder FROM UTP_ListMaster
		WHERE ListID=@ListID AND IsActive=1
		-- AND ListKey IN ()
		ORDER BY ListKey ASC,SortOrder ASC
	END
	ELSE IF @Key IS NOT NULL
	BEGIN
		SELECT ListID,ListKey,ListValue,ListText,HelpText,IsDefault,SortOrder FROM UTP_ListMaster
		WHERE ListKey=@Key AND IsActive=1
		-- AND ListKey IN ()
		ORDER BY ListKey ASC,SortOrder ASC
	END
	ELSE
	BEGIN
		SELECT ListID,ListKey,ListValue,ListText,HelpText,IsDefault,SortOrder FROM UTP_ListMaster
		WHERE IsActive=1
		--AND ListKey IN ('TaskMemoType','TaskStatus','TaskPriority','TaskType','FollowupFreq','AssignedTo')
		ORDER BY ListKey ASC,SortOrder ASC
	END
GO
/*
	GWS_GetWorkOrder
	Returns Work Orders to GAMIFIELDWS
	Create - 2019-01-17 By IDM
*/
ALTER PROCEDURE [dbo].[GWS_GetWorkOrder]
	@TechID int,
	@OrderID int = NULL
AS
	DECLARE @MaxRows int=5000

	IF @OrderID IS NOT NULL
	BEGIN
		SELECT wo.[OrderID],wo.[WONUM],g.[GroupCode],wo.[Grid],wo.[WOPriority],wo.[JobCodeID],JobCode=jc.[DisplayJobCode],
			[Address]=CASE WHEN ad.StreetNo IS NULL THEN '' ELSE ad.StreetNo + ' ' END +
				CASE WHEN ad.Unit IS NULL THEN '' ELSE ad.Unit + ' ' END +
				isnull(ad.Street,'') +
				CASE WHEN ad.StreetType IS NULL THEN '' ELSE ' ' + ad.StreetType END +
				CASE WHEN ad.Sfx IS NULL THEN '' ELSE ' ' + ad.Sfx END +
				CASE WHEN ad.LotNumber IS NULL THEN '' ELSE ' LOT ' + ad.LotNumber END,
			ad.[Town],ad.[PostalCode],[Province]=ad.[ProvinceCode],[Latitude]=CAST(NULL as float),[Longitude]=CAST(NULL as float),
			[CustomerName]=COALESCE(ctapp.[ContactName],ct.[ContactName]),
			[CustomerPhone]=COALESCE(ctapp.[ContactPhone],ctapp.[ContactAlternatePhone],ct.[ContactPhone],ct.[ContactAlternatePhone]),
			[Comments]=wo.[WONotes],[TechnicianID]=techu.[UserID],[Technician]=techu.[Username],wo.[WMStatusID],[WMStatus]=wms.[ListValue],
			[ServiceNotation]=CAST(NULL as VARCHAR(255)),a.[AppointmentID],a.[ApptStartDate],a.[ApptEndDate],a.[ApptStartTime],a.[ApptEndTime],
			a.[ExpectedDuration],a.[SpecialInstructions],
			[AppointmentType]=lmat.[ListValue],a.[AppointmentTypeID],
			a.[AccessRestricted],a.[MedicalNecessity],[IsFirmAppointment]=a.[IsFirmAppt],[AllowEarlyArrival]=a.[IsEAOK]
			FROM [dbo].[UTP_WO] wo with(nolock)
			JOIN (
				SELECT OrderID, AppointmentID=MAX(AppointmentID) FROM [dbo].[UTP_Appointment] with(nolock) WHERE [AppointmentStatusID]=90321 /*Booked*/ GROUP BY [OrderID]
			) apmax ON apmax.OrderID=wo.OrderID 
			JOIN [dbo].[UTP_Appointment] a with(nolock) ON a.[AppointmentID]=apmax.[AppointmentID]
			JOIN [dbo].[UTP_User] techu with(nolock) ON techu.[UserID]=wo.[TechnicianID]
			LEFT JOIN [dbo].[CAT_JobCode] jc with(nolock) ON jc.[JobCodeID]=wo.[JobCodeID]
			LEFT JOIN [dbo].[UTP_Group] g with(nolock) ON g.[GroupID]=wo.[AreaID]
			LEFT JOIN [dbo].[UTP_ListMaster] wms with(nolock) ON wms.[ListID]=wo.[WMStatusID]
			LEFT JOIN [dbo].[UTP_OrderAddress] oa with(nolock) ON oa.OrderID = wo.OrderID AND oa.AddressTypeID=dbo.fnUTP_GetListMaster('UTP_AddressType','SERVICE')
			LEFT JOIN [dbo].[UTP_Address] ad with(nolock) ON ad.AddressID = oa.AddressID
			LEFT JOIN [dbo].[UTP_Contact] ctapp with(nolock) ON ctapp.[ContactID]=a.[ContactID] AND ctapp.[OrderID]=wo.[OrderID]
			LEFT JOIN [dbo].[UTP_Contact] ct with(nolock) ON ct.OrderID = wo.OrderID AND ct.ContactTypeID = dbo.fnUTP_GetListMaster('ContactType','CONTACT')
			LEFT JOIN [dbo].[UTP_ListMaster] lmat with(nolock) ON lmat.ListID=a.AppointmentTypeID
			WHERE wo.[OrderID]=@OrderID AND a.[TechnicianID]=@TechID
	END
	ELSE
	BEGIN
		SELECT TOP (@MaxRows) wo.[OrderID],wo.[WONUM],g.[GroupCode],wo.[Grid],wo.[WOPriority],wo.[JobCodeID],JobCode=jc.[DisplayJobCode],
			[Address]=CASE WHEN ad.StreetNo IS NULL THEN '' ELSE ad.StreetNo + ' ' END +
				CASE WHEN ad.Unit IS NULL THEN '' ELSE ad.Unit + ' ' END +
				isnull(ad.Street,'') +
				CASE WHEN ad.StreetType IS NULL THEN '' ELSE ' ' + ad.StreetType END +
				CASE WHEN ad.Sfx IS NULL THEN '' ELSE ' ' + ad.Sfx END +
				CASE WHEN ad.LotNumber IS NULL THEN '' ELSE ' LOT ' + ad.LotNumber END,
			ad.[Town],ad.[PostalCode],[Province]=ad.[ProvinceCode],[Latitude]=CAST(NULL as float),[Longitude]=CAST(NULL as float),
			[CustomerName]=COALESCE(ctapp.[ContactName],ct.[ContactName]),
			[CustomerPhone]=COALESCE(ctapp.[ContactPhone],ctapp.[ContactAlternatePhone],ct.[ContactPhone],ct.[ContactAlternatePhone]),
			[Comments]=wo.[WONotes],[TechnicianID]=techu.[UserID],[Technician]=techu.[Username],wo.[WMStatusID],[WMStatus]=wms.[ListValue],
			[ServiceNotation]=CAST(NULL as VARCHAR(255)),a.[AppointmentID],a.[ApptStartDate],a.[ApptEndDate],a.[ApptStartTime],a.[ApptEndTime],
			a.[ExpectedDuration],a.[SpecialInstructions],
			[AppointmentType]=lmat.[ListValue],a.[AppointmentTypeID],
			a.[AccessRestricted],a.[MedicalNecessity],[IsFirmAppointment]=a.[IsFirmAppt],[AllowEarlyArrival]=a.[IsEAOK]
			FROM [dbo].[UTP_WO] wo with(nolock)
			JOIN (
				SELECT OrderID, AppointmentID=MAX(AppointmentID) FROM [dbo].[UTP_Appointment] with(nolock) WHERE [AppointmentStatusID]=90321 /*Booked*/ GROUP BY [OrderID]
			) apmax ON apmax.OrderID=wo.OrderID 
			JOIN [dbo].[UTP_Appointment] a with(nolock) ON a.[AppointmentID]=apmax.[AppointmentID]
			JOIN [dbo].[UTP_User] techu with(nolock) ON techu.[UserID]=wo.[TechnicianID]
			LEFT JOIN [dbo].[CAT_JobCode] jc with(nolock) ON jc.[JobCodeID]=wo.[JobCodeID]
			LEFT JOIN [dbo].[UTP_Group] g with(nolock) ON g.[GroupID]=wo.[AreaID]
			LEFT JOIN [dbo].[UTP_ListMaster] wms with(nolock) ON wms.[ListID]=wo.[WMStatusID]
			LEFT JOIN [dbo].[UTP_OrderAddress] oa with(nolock) ON oa.OrderID = wo.OrderID AND oa.AddressTypeID=dbo.fnUTP_GetListMaster('UTP_AddressType','SERVICE')
			LEFT JOIN [dbo].[UTP_Address] ad with(nolock) ON ad.AddressID = oa.AddressID
			LEFT JOIN [dbo].[UTP_Contact] ctapp with(nolock) ON ctapp.[ContactID]=a.[ContactID] AND ctapp.[OrderID]=wo.[OrderID]
			LEFT JOIN [dbo].[UTP_Contact] ct with(nolock) ON ct.OrderID = wo.OrderID AND ct.ContactTypeID = dbo.fnUTP_GetListMaster('ContactType','CONTACT')
			LEFT JOIN [dbo].[UTP_ListMaster] lmat with(nolock) ON lmat.ListID=a.AppointmentTypeID
			WHERE a.[TechnicianID]=@TechID
			ORDER BY wo.[OrderID] asc
	END
GO
/*
	GWS_LoginTech
	Authenticates Technician Login - returns 0 for failure or 1 for success, plus @UserID set to UserID of Logged in Technician
	Create - 2019-01-31 By IDM
*/
CREATE PROCEDURE [dbo].[GWS_LoginTech]
	@Username varchar(255),
	@Password varchar(255),
	@UserID int OUTPUT
AS
	SELECT @UserID=u.[UserID] FROM [dbo].[UTP_User] u with(nolock) 
		JOIN [dbo].[UTP_Technician] t with(nolock) ON t.[UserID]=u.[UserID]
		WHERE [UserName]=@Username AND [Password]=@Password AND t.[HasHandHeld]=1
	IF @@ROWCOUNT = 0 RETURN 0
	ELSE RETURN 1
GO
/*
	GWS_GetSpec
	Returns lists of Specs for specified work order 
	Created - 2019-01-31 By IDM
*/
CREATE PROCEDURE [dbo].[GWS_GetSpec]
	@TechID int,
	@OrderID int,
	@SpecID int = NULL
AS
	IF @SpecID IS NOT NULL
	BEGIN
		SELECT sp.[SpecID],[AttributeName]=sp.[AttributeName],sp.[AttributeValue],[DefaultValue]=isnull(cta.[DefaultValue],da.[DefaultValue]),[DataType]=isnull(cta.[DataType],'string'),
			[Caption]=isnull(cta.[SpecDescription],da.[DisplayName]),[HelpText]=COALESCE(da.[HelpText],da.[DisplayName]),
			[MaxLength]=isnull(cta.[Length],da.[Length]),[SortOrder]=isnull(cta.[SortOrder],0),[LoVKey]=CAST(isnull(cta.[LoVKey],da.[LoVKey]) as varchar(255)),
			[ControlTypeID]=CASE WHEN COALESCE(cta.[LoVKey],da.[LoVKey],'')='' THEN 70105 ELSE
				CASE isnull(cta.[DataType],'string') WHEN 'int' THEN 70103 WHEN 'datetime' THEN 70108 ELSE 70101 END END,
			[IsHidden]=CAST(0 as bit),[IsOptional]=CAST(CASE sp.IsRequired WHEN 1 THEN 0 ELSE 1 END as bit),[IsReadOnly]=sp.[IsReadony]
			FROM [dbo].[UTP_Spec] sp with(nolock)
			JOIN [dbo].[UTP_WO] wo with(nolock) ON wo.[OrderID]=sp.[OrderID]
			JOIN (
				SELECT OrderID, AppointmentID=MAX(AppointmentID) FROM [dbo].[UTP_Appointment] with(nolock) WHERE [AppointmentStatusID]=90321 /*Booked*/ GROUP BY [OrderID]
			) apmax ON apmax.OrderID=wo.OrderID 
			JOIN [dbo].[UTP_Appointment] a with(nolock) ON a.[AppointmentID]=apmax.[AppointmentID]
			JOIN [dbo].[UTP_DataAttribute] da with(nolock) ON da.[DataAttributeID]=sp.[DataAttributeID]
			LEFT JOIN [dbo].[CAT_JobCode] jc with(nolock) ON jc.[JobCodeID]=wo.[JobCodeID]
			LEFT JOIN [dbo].[vw_CAT_TemplateAttribute] cta with(nolock) ON cta.[TemplateID]=jc.[PrimaryTemplateID] AND cta.[DataAttributeID]=sp.[DataAttributeID] AND cta.[SpecTypeID]=5800 /*WOSPEC*/
			WHERE sp.[OrderID]=@OrderID AND a.[TechnicianID]=@TechID AND sp.[SpecID]=@SpecID
	END
	ELSE
	BEGIN
		SELECT sp.[SpecID],[AttributeName]=sp.[AttributeName],sp.[AttributeValue],[DefaultValue]=isnull(cta.[DefaultValue],da.[DefaultValue]),[DataType]=isnull(cta.[DataType],'string'),
			[Caption]=isnull(cta.[SpecDescription],da.[DisplayName]),[HelpText]=COALESCE(da.[HelpText],da.[DisplayName]),
			[MaxLength]=isnull(cta.[Length],da.[Length]),[SortOrder]=isnull(cta.[SortOrder],0),[LoVKey]=CAST(isnull(cta.[LoVKey],da.[LoVKey]) as varchar(255)),
			[ControlTypeID]=CASE WHEN COALESCE(cta.[LoVKey],da.[LoVKey],'')='' THEN 70105 ELSE
				CASE isnull(cta.[DataType],'string') WHEN 'int' THEN 70103 WHEN 'datetime' THEN 70108 ELSE 70101 END END,
			[IsHidden]=CAST(0 as bit),[IsOptional]=CAST(CASE sp.IsRequired WHEN 1 THEN 0 ELSE 1 END as bit),[IsReadOnly]=sp.[IsReadony]
			FROM [dbo].[UTP_Spec] sp with(nolock)
			JOIN [dbo].[UTP_WO] wo with(nolock) ON wo.[OrderID]=sp.[OrderID]
			JOIN (
				SELECT OrderID, AppointmentID=MAX(AppointmentID) FROM [dbo].[UTP_Appointment] with(nolock) WHERE [AppointmentStatusID]=90321 /*Booked*/ GROUP BY [OrderID]
			) apmax ON apmax.OrderID=wo.OrderID 
			JOIN [dbo].[UTP_Appointment] a with(nolock) ON a.[AppointmentID]=apmax.[AppointmentID]
			JOIN [dbo].[UTP_DataAttribute] da with(nolock) ON da.[DataAttributeID]=sp.[DataAttributeID]
			LEFT JOIN [dbo].[CAT_JobCode] jc with(nolock) ON jc.[JobCodeID]=wo.[JobCodeID]
			LEFT JOIN [dbo].[vw_CAT_TemplateAttribute] cta with(nolock) ON cta.[TemplateID]=jc.[PrimaryTemplateID] AND cta.[DataAttributeID]=sp.[DataAttributeID] AND cta.[SpecTypeID]=5800 /*WOSPEC*/
			WHERE sp.[OrderID]=@OrderID AND a.[TechnicianID]=@TechID
			ORDER BY sp.[SpecID] asc
	END
	RETURN @@ROWCOUNT
GO
/*
	GWS_WOCompletionType
	Contains data for Work Order completion processing
	Created - 2019-02-01 By IDM
*/
CREATE TYPE [dbo].[GWS_WOCompletionType] AS TABLE (
	[OrderID] [INT] NULL,
	[AppointmentID] [INT] NULL,
	[TechnicianID] [INT] NULL,
	[CompletionCode] [varchar](20) NULL,
	[ActualStart] [DATETIME] NULL,
	[ActualFinish] [DATETIME] NULL,
	[AppTimestamp] [DATETIME] NULL,
	[Latitude] [float] NULL,
	[Longitude] [float] NULL
)
GO
/*
	GWS_SpecCompletionType
	Contains spec data used in Work Order completion processing
	Created - 2019-02-01 By IDM
*/
CREATE TYPE [dbo].[GWS_SpecCompletionType] AS TABLE (
	[SpecID] [INT] NULL,
	[AttributeName] [varchar](255) NULL,
	[AttributeValue] [varchar](255) NULL
)
GO
/*
	GWS_CompleteWorkOrder
	Process a Work Order completion from the mobile app
	Returns 0 for failure, positive integer for success
	Created - 2019-02-01 By IDM
*/
CREATE PROCEDURE [dbo].[GWS_CompleteWorkOrder]
	@TechID INT,
	@WOCompletion [dbo].[GWS_WOCompletionType] READONLY,
	@SpecCompletion [dbo].[GWS_SpecCompletionType] READONLY
AS
	RETURN 1
GO
/*
	GWS_GMAEvent
	Contains mobile app event information
	Created - 2019-02-04 By IDM
*/
CREATE TYPE [dbo].[GWS_GMAEvent] AS TABLE (
	[OrderID] INT NULL,
	[AppointmentID] INT NULL,
	[TechnicianID] INT NULL,
	[Action] [varchar](255) NULL,
	[AppTimestamp] DATETIME NULL,
	[Latitude] [float] NULL,
	[Longitude] [float] NULL
)
GO
/*
	GWS_PostEvent
	Process mobile app events
	Returns zero for failure or positive integer for success
	Created - 2019-02-04 By ID
*/
CREATE PROCEDURE [dbo].[GWS_PostEvent]
	@TechID INT,
	@OrderID INT,
	@GMAEvent [dbo].[GWS_GMAEvent] READONLY
AS
	RETURN 1
GO
