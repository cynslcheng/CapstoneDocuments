/*
alter table UTP_Technician drop [TCH_RCC]
alter table UTP_Technician drop TCH_DEFRCC
ALTER TABLE UTP_Technician drop column ResourceCostCodeID
GO
DROP TABLE UTP_JobCodeSkills
DROP TABLE UTP_ResourceSkills
DROP TABLE UTP_SkillRating
DROP TABLE UTP_Skills
DROP TABLE UTP_CostCode
*/
---------------------------------------------------------------

CREATE TABLE UTP_CostCode 
(
	[ResourceCostCodeID] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[ResourceCostCodeDescription]	varchar(255) not null,
	[ResourceCostCodeRate]	decimal(9,2),
	[IsActive] [bit] NULL CONSTRAINT [CC_PersonIA]  DEFAULT ((1)),
	[CreatedByID] [int] NULL,
	[CreatedTimestamp] [datetime] NULL CONSTRAINT [CC_DateCreated]  DEFAULT (getdate()),	
)
GO
INSERT INTO [UTP_CostCode]([ResourceCostCodeDescription],[ResourceCostCodeRate],[IsActive] ) VALUES ('Default',1,1)
--select * From [UTP_CostCode]
GO

alter table UTP_Technician add ResourceCostCodeID INT NOT NULL CONSTRAINT TCH_DEFRCC DEFAULT 1 CONSTRAINT [TCH_RCC] REFERENCES [dbo].UTP_CostCode (ResourceCostCodeID)

CREATE TABLE UTP_Skills
(
	[SkillID] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[SkillDescription]	varchar(255) not null,
	[SkillLevel} int not null,
	[IsActive] [bit] NULL CONSTRAINT [SK_PersonIA]  DEFAULT ((1)),
	[CreatedByID] [int] NULL,
	[CreatedTimestamp] [datetime] NULL CONSTRAINT [SK_UTP_Person_Created]  DEFAULT (getdate()),	
)

CREATE TABLE UTP_SkillRating 
(
	[SkillRatingID] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[SkillRatingRatio] real not null,
	[SKillRatingDescription varchar(255) not null,
	[IsActive] [bit] NULL CONSTRAINT [SKR_PersonIA]  DEFAULT ((1)),
	[CreatedByID] [int] NULL,
	[CreatedTimestamp] [datetime] NULL CONSTRAINT [SKR_DateCreated]  DEFAULT (getdate()),	
)
 
CREATE TABLE UTP_ResourceSkills
(
	[ResourceSkillID] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[ResourceID] int not null,
	[ResourceTypeID] int not null, -- 1=UTP-Technician
	[SkillID] INT NOT NULL REFERENCES [dbo].UTP_Skills ([SkillID]),
	[SkillRatingID] INT NOT NULL REFERENCES [dbo].UTP_SkillRating (SkillRatingID),
	[SkillExpirationDate] datetime not null,
	[IsActive] [bit] NULL CONSTRAINT [RSK_PersonIA]  DEFAULT ((1)),
	[CreatedByID] [int] NULL,
	[CreatedTimestamp] [datetime] NULL CONSTRAINT [RSK_DateCreated]  DEFAULT (getdate()),	
)
 
CREATE TABLE UTP_JobCodeSkills
(
	[JobCodeID] int NOT NULL REFERENCES [dbo].CAT_JobCode ([JobCodeID]),
	[SkillID] INT NOT NULL REFERENCES [dbo].UTP_Skills ([SkillID]),
	[IsActive] [bit] NULL CONSTRAINT [JCS_PersonIA]  DEFAULT ((1)),
	[CreatedByID] [int] NULL,
	[CreatedTimestamp] [datetime] NULL CONSTRAINT [JCS_DateCreated]  DEFAULT (getdate())
)
GO

