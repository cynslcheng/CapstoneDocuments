/*
	GWS_GetListMaster
	Returns List Master entries to GAMIFIELDWS
	Created - 2019-01-17 by IDM
*/
CREATE PROCEDURE [dbo].[GWS_GetListMaster]
	@ListID int = NULL,
	@Key varchar(255) = NULL
AS
	IF @ListID IS NOT NULL
	BEGIN
		SELECT ListID,ListKey,ListValue,HelpText,IsDefault,SortOrder FROM UTP_ListMaster
		WHERE ListID=@ListID AND IsActive=1
		-- AND ListKey IN ()
		ORDER BY ListKey ASC,SortOrder ASC
	END
	ELSE IF @Key IS NOT NULL
	BEGIN
		SELECT ListID,ListKey,ListValue,HelpText,IsDefault,SortOrder FROM UTP_ListMaster
		WHERE ListKey=@Key AND IsActive=1
		-- AND ListKey IN ()
		ORDER BY ListKey ASC,SortOrder ASC
	END
	ELSE
	BEGIN
		SELECT ListID,ListKey,ListValue,HelpText,IsDefault,SortOrder FROM UTP_ListMaster
		WHERE IsActive=1
		--AND ListKey IN ('TaskMemoType','TaskStatus','TaskPriority','TaskType','FollowupFreq','AssignedTo')
		ORDER BY ListKey ASC,SortOrder ASC
	END
GO
/*
	GWS_GetWorkOrder
	Returns Work Orders to GAMIFIELDWS
	Create - 2019-01-17 By IDM
*/
CREATE PROCEDURE [dbo].[GWS_GetWorkOrder]
	@OrderID int = NULL
AS
	DECLARE @MaxRows int=500

	IF @OrderID IS NOT NULL
	BEGIN
		SELECT wo.[OrderID],wo.[WONUM],wo.[JobCodeID],JobCode=jc.[DisplayJobCode],wo.[AreaID],g.[GroupCode],wo.[DueDate],wo.[WMStatusID],WMStatus=wms.[ListValue],
			wo.[DispatcherID],Dispatcher=dispu.[Username],wo.[TechnicianID],Technician=techu.[Username],wo.[CompletionCode],
			wo.[ActualStart],wo.[ActualFinish],wo.[Grid],wo.[WONotes],wo.[WODescription],wo.[ServiceAddress],wo.[WOPriority]
			FROM [dbo].[UTP_WO] wo with(nolock)
			LEFT JOIN [dbo].[CAT_JobCode] jc with(nolock) ON jc.[JobCodeID]=wo.[JobCodeID]
			LEFT JOIN [dbo].[UTP_Group] g with(nolock) ON g.[GroupID]=wo.[AreaID]
			LEFT JOIN [dbo].[UTP_ListMaster] wms with(nolock) ON wms.[ListID]=wo.[WMStatusID]
			LEFT JOIN [dbo].[UTP_User] dispu with(nolock) ON dispu.[UserID]=wo.[DispatcherID]
			LEFT JOIN [dbo].[UTP_User] techu with(nolock) ON techu.[UserID]=wo.[TechnicianID]
			LEFT JOIN [dbo].[UTP_Person] per with(nolock) ON per.[PersonID]=wo.[PersonID]
			WHERE [OrderID]=@OrderID
	END
	ELSE
	BEGIN
		SELECT TOP (@MaxRows) wo.[OrderID],wo.[WONUM],wo.[JobCodeID],JobCode=jc.[DisplayJobCode],wo.[AreaID],g.[GroupCode],wo.[DueDate],wo.[WMStatusID],WMStatus=wms.[ListValue],
			wo.[DispatcherID],Dispatcher=dispu.[Username],wo.[TechnicianID],Technician=techu.[Username],wo.[CompletionCode],
			wo.[ActualStart],wo.[ActualFinish],wo.[Grid],wo.[WONotes],wo.[WODescription],wo.[ServiceAddress],wo.[WOPriority]
			FROM [dbo].[UTP_WO] wo with(nolock)
			LEFT JOIN [dbo].[CAT_JobCode] jc with(nolock) ON jc.[JobCodeID]=wo.[JobCodeID]
			LEFT JOIN [dbo].[UTP_Group] g with(nolock) ON g.[GroupID]=wo.[AreaID]
			LEFT JOIN [dbo].[UTP_ListMaster] wms with(nolock) ON wms.[ListID]=wo.[WMStatusID]
			LEFT JOIN [dbo].[UTP_User] dispu with(nolock) ON dispu.[UserID]=wo.[DispatcherID]
			LEFT JOIN [dbo].[UTP_User] techu with(nolock) ON techu.[UserID]=wo.[TechnicianID]
			LEFT JOIN [dbo].[UTP_Person] per with(nolock) ON per.[PersonID]=wo.[PersonID]
			ORDER BY wo.[OrderID] DESC
	END
GO
