/*
 * FILE         : JDBCBean.java
 * PROJECT      : PROG3060 - Assignment #1
 * PROGRAMMER   : Thomas Craig
 * FIRST VERSION: 01/02/2019
 * DESCRIPTION  : This file holds all of the database logic, connecting to the database 
 * 					and prepared statements for retrieving information
 */
package prog3060.tcraig;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import prog3060.models.GeographicArea;

public class JDBCBean {

	static final String CONNECTION_STRING = "jdbc:derby://localhost:1527/CanadaCensusDB";

    private static final String PERSISTENCE_UNIT_NAME = "TCraigAssignment1";
    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager entityManager;
	static int geoLevel = 0;
	static int geoCode = 0;

	//opens a database connection given a username and password
	public static void OpenConnection(String tempUser, String tempPassword) throws SQLException {
		
 	try { Properties properties = new Properties();
 		properties.setProperty("hibernate.connection.username", tempUser);
 		properties.setProperty("hibernate.connection.password", tempPassword);
 		entityManagerFactory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
 		entityManager = entityManagerFactory.createEntityManager();
 		entityManager.getTransaction().begin();
		//Properties tempConnectionProperties = new Properties();
		//tempConnectionProperties.put("user", tempUser);
		//tempConnectionProperties.put("password", tempPassword);

		//tempConnection = DriverManager.getConnection(CONNECTION_STRING, tempConnectionProperties);

		//tempConnection.setAutoCommit(false);
		//tempConnection.createStatement().executeUpdate("SET SCHEMA APP");
		} catch (Exception e) {
			e.printStackTrace();
			entityManager = null;
		}
	}

	//checks to make sure the connection is open
	public static Boolean testConnection() {
		return entityManager != null;
	}

	//gets the regions on the census and there levels
	public static List<String> GetRegions() {
		String tempSQLSelectQuery = "SELECT ga " 
				+ "FROM GeographicArea ga " + "ORDER BY ga.level";
		
	
		List<String> tempOutputTable = new ArrayList<String>();
		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			List<GeographicArea> geographicAreaList = query.getResultList();
			
			
			for (GeographicArea geographicArea : geographicAreaList)
			{
				String tempName = geographicArea.getName();
				int tempLevel = geographicArea.getLevel();
				int tempCode = geographicArea.getCode();

				tempOutputTable.add(
						String.format("%5d", tempLevel) + String.format("%10s", ",") + String.format("%100s", tempName)
								+ String.format("%10s", ",") + String.format("%5d", tempCode));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempOutputTable;
	}

	public static void setGeoLevel(String tempLevel) {
		geoLevel = Integer.parseInt(tempLevel);
	}

	public static void setGeoCode(String tempCode) {
		geoCode = Integer.parseInt(tempCode);
	}

	//uses the geolevel and geocode to get the name, code, level, and total population of the region
	public static List<String> GetRegionDetails() {
		
//		String tempSQLSelectQuery = "SELECT name, code, level, combined, male, female, CENSUSYEAR.censusyear " + "FROM AGE "
//				+ "JOIN GEOGRAPHICAREA ON GEOGRAPHICAREA.CODE = AGE.GEOGRAPHICAREA "
//				+ "JOIN CENSUSYEAR ON AGE.CENSUSYEAR = CENSUSYEAR.CENSUSYEARID WHERE "
//				+ "AGEGROUP = 1 " + "AND CODE = ? AND LEVEL = ?";
//		entityManager.createQuery("SELECT  t.league FROM Roster r JOIN r.team t"
		
		String tempSQLSelectQuery = "SELECT ga.name, ga.code, ga.level, a.combined, a.male, a.female, cy.censusYear "
				+ "FROM Age a "
				+ "JOIN a.geographicArea ga "
				+ "JOIN a.censusYear cy "
				+ "WHERE a.ageGroup = 1 AND ga.code = : geoCode AND ga.level = : geoLevel";

		List<String> tempOutputTable = new ArrayList<String>();
		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
	        query.setParameter("geoCode", geoCode);
	        query.setParameter("geoLevel", geoLevel);
			//PreparedStatement tempPreparedStatement = tempConnection.prepareStatement(tempSQLSelectQuery);
			//tempPreparedStatement.setString(1, geoCode);
			//tempPreparedStatement.setInt(2, geoLevel);
			//ResultSet tempResultSet = tempPreparedStatement.executeQuery();
			List<Object[]> resultList = query.getResultList();
           	Iterator<Object[]> iterator = resultList.iterator();
			if (geoLevel < 2)
			{
				
			}

			while (iterator.hasNext()) {
				Object[] tempResultSet = iterator.next();
				String tempName = tempResultSet[0].toString();
				int tempCode = Integer.parseInt(tempResultSet[1].toString());
				int tempLevel = Integer.parseInt(tempResultSet[2].toString());
				int tempPop = Integer.parseInt(tempResultSet[3].toString());
				int tempMale = Integer.parseInt(tempResultSet[4].toString());
				int tempFemale = Integer.parseInt(tempResultSet[5].toString());
				int tempYear = Integer.parseInt(tempResultSet[6].toString());
				

				tempOutputTable.add(String.format("%5d", tempLevel)
						+ String.format("%10s", ",")
						+ String.format("%30s", tempName)
						+ String.format("%10s", ",")
						+ String.format("%5d", tempCode)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempPop)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempMale)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempFemale)
						+ String.format("%10s", ",")
						+ String.format("%15d", tempYear));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return tempOutputTable;

	}

	//uses the geolevel and geocode to get all the regions located within the region at the next level down
	public static List<String> GetRegionsBelow() {
//		String tempSQLSelectQuery = "SELECT name, level, alternativecode " + "FROM GEOGRAPHICAREA " + "WHERE (? = 0 AND LEVEL = 1) OR "
//				+ "(? <> 0 AND LEVEL = ? AND CAST(ALTERNATIVECODE AS CHAR(10)) LIKE ? ) "
//				+ "ORDER BY alternativecode DESC";
		String tempSQLSelectQuery = "SELECT ga FROM GeographicArea ga "
				                    + "WHERE (0 = : geoLevel AND ga.level = 1) OR "
				                    + "(0 <> : geoLevel AND ga.level = : geoLevel AND CAST(ga.alternativeCode AS CHAR(10)) LIKE : geoCode) "
				                    + "ORDER BY ga.alternativeCode DESC";
		List<String> tempOutputTable = new ArrayList<String>();

		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			query.setParameter("geoLevel", geoLevel);
			query.setParameter("geoLevel", geoLevel);
			query.setParameter("geoLevel", geoLevel);
			query.setParameter("geoCode", geoCode);
			
//			tempPreparedStatement.setInt(1, geoLevel);
//			tempPreparedStatement.setInt(2, geoLevel);
//			tempPreparedStatement.setInt(3, geoLevel + 1);
//			tempPreparedStatement.setString(4, geoCode + "%");
			
			List<GeographicArea> geographicAreaList = query.getResultList();

//			ResultSet tempResultSet = tempPreparedStatement.executeQuery();


			for (GeographicArea geographicArea : geographicAreaList)
			{
				String tempName = geographicArea.getName();
				int tempLevel = geographicArea.getLevel();
				int tempAltCode = geographicArea.getAlternativeCode();

				tempOutputTable.add(String.format("%5d", tempLevel) + String.format("%10s", ",") + String.format("%30s", tempName)
				+ String.format("%10s", ",") + String.format("%30s", tempAltCode));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tempOutputTable;
	}

	//gets the male and female population broken down by census year and age group, with age groups being in chunks of 5 years
	public static List<String> GetAgeDetails() {
//		String tempSQLSelectQuery = "SELECT description, male, female, CENSUSYEAR.censusyear " + "FROM AGEGROUP "
//				+ "JOIN AGE ON AGEGROUP.AGEGROUPID = AGE.AGEGROUP "
//				+ "JOIN CENSUSYEAR ON CENSUSYEAR.censusyearid = AGE.censusyear " + "WHERE GEOGRAPHICAREA = 1 "
//				+ "AND AGE.AGEGROUP IN (3, 9, 15, 22, 28, 34, 40, 46, 52, 58, 64, 70, 76, 83, 89, 95, 101, 108, 114, 120, 126) "
//				+ "ORDER BY AGEGROUP, AGE.CENSUSYEAR DESC";

		String tempSQLSelectQuery = "SELECT ag.description, a.male, a.female, cy.censusYear "
				+ "FROM Age a "
				+ "JOIN a.ageGroup ag "
				+ "JOIN a.censusYear cy "
				+ "JOIN a.geographicArea ga "
				+ "WHERE ga.geographicAreaID = 1 "
				+ "AND a.ageGroup IN (3, 9, 15, 22, 28, 34, 40, 46, 52, 58, 64, 70, 76, 83, 89, 95, 101, 108, 114, 120, 126) "
				+ "ORDER BY a.ageGroup, a.censusYear DESC";
		List<String> tempOutputTable = new ArrayList<String>();

		try {
			Query query = entityManager.createQuery(tempSQLSelectQuery);
			List<Object[]> resultList = query.getResultList();
           	Iterator<Object[]> iterator = resultList.iterator();
           	
//			PreparedStatement tempPreparedStatement = tempConnection.prepareStatement(tempSQLSelectQuery);
//
//			ResultSet tempResultSet = tempPreparedStatement.executeQuery();

			while (iterator.hasNext()) {
				Object[] tempResultSet = iterator.next();
				String tempName = tempResultSet[0].toString();
				String tempYear = tempResultSet[1].toString();
				int tempMale = Integer.parseInt(tempResultSet[3].toString());
				int tempFemale = Integer.parseInt(tempResultSet[4].toString());

				tempOutputTable.add(String.format("%30s", tempName) + String.format("%10s", ",")
						+ String.format("%10s", tempYear) + String.format("%10s", ",") + String.format("%15d", tempMale)
						+ String.format("%10s", ",") + String.format("%15d", tempFemale));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tempOutputTable;
	}

	public static List<String> GetHouseholdIncomeDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
