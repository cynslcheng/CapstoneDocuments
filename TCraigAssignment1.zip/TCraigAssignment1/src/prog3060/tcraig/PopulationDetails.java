/*
 * FILE         : PopultionDetails.java
 * PROJECT      : PROG3060 - Assignment #1
 * PROGRAMMER   : Thomas Craig
 * FIRST VERSION: 01/02/2019
 * DESCRIPTION  : This file retrieves the age information from the JDBC and passes it to the Ages page through the session
 */
package prog3060.tcraig;

import java.io.IOException;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "PopulationDetails", urlPatterns = {"/PopulationDetails"})
public class PopulationDetails extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	doPost(request,response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        HttpSession tempSession = request.getSession();

        List <String> tempAgesList = JDBCBean.GetAgeDetails();
        tempSession.setAttribute("ages", tempAgesList);
    	response.sendRedirect("./Ages.jsp");

    }

}
