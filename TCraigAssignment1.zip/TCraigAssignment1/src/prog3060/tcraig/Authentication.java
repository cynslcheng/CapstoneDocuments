/*
 * FILE         : Authentication.java
 * PROJECT      : PROG3060 - Assignment #1
 * PROGRAMMER   : Thomas Craig
 * FIRST VERSION: 01/02/2019
 * DESCRIPTION  : This file validates the login credentials by attempting to open a database connection with them
 * 					if successful it will redirect to the Main page otherwise it will return to the Login page
 * 					with an error message
 */
package prog3060.tcraig;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Authentication", urlPatterns = {"/Authentication"})
public class Authentication extends HttpServlet
{

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        HttpSession tempSession = request.getSession();
        String tempUser = request.getParameter("user");
        String tempPassword = request.getParameter("password");

        if ("".equals(tempUser) || "".equals(tempPassword))
        {
            response.sendRedirect("./Login.jsp");
        }
        else
        {
            try {
				JDBCBean.OpenConnection(tempUser, tempPassword);
			} catch (SQLException e) {
				e.printStackTrace();
			}
            //checks to make sure there is a valid database connection open
            if (JDBCBean.testConnection()) {
            	List <String> tempList = JDBCBean.GetRegions();
            	tempSession.setAttribute("regions", tempList);
            	tempSession.setAttribute("error", "");
            	response.sendRedirect("./Main.jsp");
            }
            else {
            	tempSession.setAttribute("error", "Username or Password Invalid");
            	response.sendRedirect("./Login.jsp");
            }

        }

        

    }
}
