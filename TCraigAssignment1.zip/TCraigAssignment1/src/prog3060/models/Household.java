package prog3060.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="HOUSEHOLD", schema="APP")
public class Household {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID", nullable = false)
	private int ID;
	
	@ManyToOne
	@JoinColumn(name="GEOGRAPHICAREA", nullable = false)
	private GeographicArea geographicArea;
	
	@ManyToOne
	@JoinColumn(name="HOUSEHOLDTYPE", nullable = false)
	private HouseholdType householdType;
	
	@ManyToOne
	@JoinColumn(name="HOUSEHOLDSIZE", nullable = false)
	private HouseholdSize householdSize;
	
	@ManyToOne
	@JoinColumn(name="HOUSEHOLDBYAGERANGE", nullable = false)
	private HouseholdByAgeRange householdByAgeRange;
	
	@ManyToOne
	@JoinColumn(name="HOUSEHOLDEARNERS", nullable = false)
	private HouseholdEarners householdEarners;
	
	@ManyToOne
	@JoinColumn(name="TOTALINCOME", nullable = false)
	private TotalIncome totalIncome;
	
	@Column(name="CENSUSYEAR", nullable = false)
	private int censusYear;
	
	@Column(name="NUMBERREPORTED", nullable = false)
	private int numberReported;

	public Household() {
		
	}
	
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public GeographicArea getGeographicArea() {
		return geographicArea;
	}

	public void setGeographicArea(GeographicArea geographicArea) {
		this.geographicArea = geographicArea;
	}

	public HouseholdType getHouseholdType() {
		return householdType;
	}

	public void setHouseholdType(HouseholdType householdType) {
		this.householdType = householdType;
	}

	public HouseholdSize getHouseholdSize() {
		return householdSize;
	}

	public void setHouseholdSize(HouseholdSize householdSize) {
		this.householdSize = householdSize;
	}

	public HouseholdByAgeRange getHouseholdByAgeRange() {
		return householdByAgeRange;
	}

	public void setHouseholdByAgeRange(HouseholdByAgeRange householdByAgeRange) {
		this.householdByAgeRange = householdByAgeRange;
	}

	public HouseholdEarners getHouseholdEarners() {
		return householdEarners;
	}

	public void setHouseholdEarners(HouseholdEarners householdEarners) {
		this.householdEarners = householdEarners;
	}

	public TotalIncome getTotalIncome() {
		return totalIncome;
	}

	public void setTotalIncome(TotalIncome totalIncome) {
		this.totalIncome = totalIncome;
	}

	public int getCensusYear() {
		return censusYear;
	}

	public void setCensusYear(int censusYear) {
		this.censusYear = censusYear;
	}

	public int getNumberReported() {
		return numberReported;
	}

	public void setNumberReported(int numberReported) {
		this.numberReported = numberReported;
	}
}
